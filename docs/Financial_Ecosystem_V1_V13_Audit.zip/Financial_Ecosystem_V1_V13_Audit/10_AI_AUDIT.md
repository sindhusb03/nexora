# 10 — AI Audit

V9 and V13 agree: AI explains, proposes, and retrieves. The kernel publishes numbers. Documents are data, not instructions.

## Architecture on `dev`

```text
User → chat routes → cfoBrain/pipeline.ts
     → fixed server-side tool map (read-only, company-scoped SQL)
     → OpenRouter via server/lib/aiClient.ts
     → responseQuality.ts keyword score
     → chat history write
```

There is no AI Gateway process, no intent/risk classifier, no retrieval planner, no model router across providers, and no response validator that checks digits against tool output.

Provider: OpenRouter only (`server/lib/openRouterModelConfig.ts`, `server/accounting/openrouter.ts`). Cost tracking: `server/utils/aiCostTracker.ts`. Per-org budget caps are an open item in `docs/launch/2026-08-risk-register.md` (P1-013).

## Does AI mutate financial state?

| Path | Mutates books? |
| --- | --- |
| CFO tools in `chatService.ts` (`getFinancialSummary`, `getBalanceSheet`, `getProjections`, `getEquityCapTable`, `getValuationModels`, …) | No. Read-only. The model does not choose tools; the server runs a fixed map. |
| `POST /api/accounting/transactions/ai-categorize-batch` | Returns suggestions. Posting is a separate user action. |
| `POST /transactions` when the client did not set `aiCategorized` | A learned pattern or model suggestion with confidence above 0.7 can replace debit and credit accounts before insert. Replacement is not re-validated. |
| Tax-rate suggestion | Can create a “Tax Payable” account flagged `aiSuggested`. |
| Projection narrative | Does not write `saved_projections` by itself. |

So AI does not have a `post_journal` or `publish_financial_state` tool. It can still change the accounts on a user post, and it can insert a chart account. That is the governance hole. V13-AI-001 is only partly met.

Chat suggested actions are returned to the UI for the user to run. That matches proposal mode for those buttons.

## RAG, injection, evidence

No `pgvector`, embeddings, or vector dependency under `server/`, `shared/`, `migrations/`, or `package.json`. Context is SQL assembled for the company. Authorization is “the tool query includes company id,” not “filter before rank,” because there is no ranker.

`server/lib/piiSanitizer.ts` redacts cards, SSNs, emails, phones, and account-number patterns. It is not an injection defense.

`responseQuality.ts` scores replies by keywords such as “source” and “based on.” A fluent sentence can pass. The July branch adds `server/services/cfoBrain/projectionCitationPolicy.ts` and tests that block projection claims without evidence. That code is not on `dev`.

No evaluation set for groundedness, numeric accuracy, cross-tenant retrieval, or a malicious-document corpus. No record of tool name, argument hash, and policy decision as an append-only AI audit.

## Human approval

Normalization defaults to approved without AI in the loop. AI mapping suggestions during categorization are not a V13 proposed-adjustment workflow. There is no human-approval object for model output.

## Separation verdict

AI is mostly beside the ledger, which is the right shape. It is not a V9 gateway. The categorize overwrite and the tax-account insert are the places it touches financial master data. Projection numbers can still be wrong in chat because nothing on `dev` recomputes the claim against `projection_calculate_audit`.
