# 00 — Executive Summary

**Audit date:** 29 September 2026  
**Specification baseline:** `Financial_Ecosystem_V1_V13_Master.zip` (427,962 bytes, extracted outside the repo)  
**Code baseline:** LedgerMind working tree, branch `dev` at `426751887` (`Merge PR #23: agent SDLC contract and verified CI repairs`)  
**Production branch:** `main` / `origin/main` at `e606c4bae` (`Dev (#22)`), 27 September 2026  
**Tags:** none  
**Repository was not modified.** Reports live outside the git tree.

This audit answers one question: how much of the Financial Ecosystem V1–V13 architecture has been genuinely implemented, integrated, tested, governed, secured, and made production-ready across Git history.

## A. How much of V1–V13 is actually implemented?

**Weighted coverage of the scored requirement set: 31.9%.**  
Method, counts, and weights are in `domain_coverage.csv` and `04_V1_V13_TRACEABILITY_MATRIX.md`. A requirement is not “implemented” because a similarly named file exists.

The 31.9% figure and `domain_coverage.csv` are the scored totals. The version rows below are readings of the requirements that primarily belong to that version. They are not a second weighted mean.

| Slice | Reading | What the code shows |
| --- | ---: | --- |
| V1 roles, lifecycle, AI governance, M&A, board | Partial | Personas exist as navigation and team roles, not as the specified role model. Board packs are real. M&A execution is not. |
| V2 engineering gates (ontology, ledger, consolidation, FX, graph, golden, contracts) | Largely open | V2 PDF bodies are one-page outlines and several are misfiled. The code meets almost none of the P0 gates as specified. |
| V3 / V7 financial kernel | Partial engines, no kernel | Deterministic projection engines exist. A canonical, immutable, versioned financial kernel does not. |
| V4 MVP loop (books → state → model → scenario → valuation → board) | Closest match, with gaps | The product loop exists in a different architecture, with a client-save bypass and two financial lanes. |
| V5 / V6 platform (services, schema, OpenAPI, events, IaC) | Partial | Modular monolith, Postgres, sessions, and CI exist. The specified service map, `/v1` contracts, and IaC do not. |
| V8 web + Excel | Web yes, add-in no | Web product is substantial. Excel is import/export, not a controlled add-in. |
| V9 AI | Copilot only | Grounded chat over read-only tools exists. RAG, injection defense, and approval-gated tools do not. |
| V10 M&A / data room / diligence | Handoff only | A NexaDeals handoff exists. The in-app deal state machine and data room were removed. |
| V11 debt / equity / cap table / LBO | Strongest capital slice | Debt schedules, cap table CRUD, and an LBO engine are real. Covenants, waterfall, and fundraising close are not. |
| V12 enterprise / jurisdiction | Auth only | Auth, MFA, and audit hashing are real. Multi-GAAP, residency, and SOX-style maker-checker are not. |
| V13 onboarding, 13-week cash, normalization, QoE, diligence, bridges | Mostly absent | Onboarding and income-statement adjustments are partial. The V13 engines are absent. A 13-week tab and a data room existed in history and were removed. |

By domain, modeling, forecasting, valuation, debt, security, and board reporting are the mature areas. Consolidation, FX translation, the calculation graph, 13-week cash, QoE, diligence, and the Excel add-in are not.

## B. What is the real current architecture?

LedgerMind is a React + Vite client and an Express modular monolith on PostgreSQL (Drizzle). It is not the V5 service topology.

Two financial lanes run side by side:

1. **CFO upload lane.** Excel/CSV statements land in `uploaded_financial_statements.parsedData`. Republish replaces the current statement. Mappings live in `cfo_line_item_mappings`.
2. **Accounting GL lane.** `accounts` plus `transactions` rows that each hold one debit account, one credit account, and one amount. There is no journal header/lines aggregate.

Forecasting is a large imperative TypeScript engine under `shared/projections/` (growth, scenario, KPI), executed on the server when server authority is on, and also on the client. Valuation (DCF, multiples, LBO) and board-pack PDFs sit on top of that. AI calls OpenRouter through a chat/tool layer that reads company data and does not post journals by itself. Identity is session-based with company RBAC. There is no separate Financial State service, Calculation Graph service, FX service, or Consolidation service.

`main` and `dev` are close in product code. `dev` adds the agent SDLC contract (PR #23) and small fixes. The architecture above is the architecture on both.

## C. What is the strongest existing implementation?

Evidence, not filenames:

1. **Three-statement projection engines** in `shared/projections/`, with server calculation in `server/services/projectionCalculateService.ts`, input/output fingerprints, `ENGINE_VERSION` `1.2.0`, and regression tests for balance-sheet identity, cash roll-forward, and retained-earnings roll-forward (`tests/threeStatementIntegrity.regression.test.ts`).
2. **DCF and LBO engines.** `shared/valuation/dcfCalculations.ts`, `server/services/modelingEvaluateService.ts`, `server/services/valuation/lbo/*`, with sources-equals-uses covered in `tests/lboEngine.test.ts`. LBO revisions are stored as versions.
3. **Board-pack publication.** `server/services/boardPackLifecycle.ts` refuses edits after publish and pins a currency snapshot.
4. **Authentication and company authorization.** Session cookies, TOTP MFA for admins, `authorizationService.ts`, and `attachCompanyContext`. Cross-tenant tests exist, mostly against mocks.
5. **Debt schedules and cap-table records.** `debt.routes.ts`, `capital-markets.routes.ts`.
6. **Bank reconciliation matching** serialized with row locks (`server/accounting/reconciliation.ts`).

These are production-shaped application features. They are not a V7 kernel.

## D. What is missing?

P0 gaps, in dependency order:

- No canonical, versioned, immutable financial state.
- Posted GL rows can be updated and hard-deleted. No reversal model. Period locks do not cover every mutation.
- No consolidation (ownership, eliminations, NCI, CTA). Pricing and blog copy claim it.
- No FX translation or remeasurement. Mixed-currency GL amounts can be summed. Upload ingestion blocks currency mismatch instead of converting.
- No formula DAG, cycle detection, or incremental recalculation. Projection math uses binary floats.
- Projection save accepts client-computed grids unless `PROJECTION_STRICT_SAVE=true`.
- No 13-week cash engine, QoE case, diligence workflow, transaction bridge, or readiness certificate.
- No Excel add-in. No RAG. No `/v1` financial API. No Terraform/Kubernetes. No proven restore.

## E. What exists in branches but not main?

| Branch | Commit | Not in `dev`/`main` | Merge posture |
| --- | --- | --- | --- |
| `audit/global-financial-engine-2026-07` | `4d526b4a7` | DCF timing, fiscal capex, covenant/ratio authority, AI projection citation policy, audit recompute tests | Valuable and stale. 74 commits behind `dev`. Port, do not merge. |
| `feat/guided-cfo-workspace` | `339d41021` | Ledger posting/close policy, five-country import groundwork, guided CFO workspace | Checkpoint. Still tracks customer files under `uploads/`. |
| `fix/production-readiness-20260927` | `60d42025e` | Same ledger/import groundwork, and it untracks those upload files | Sibling of the guided branch. |
| `feat/saml-signature-verification` | `fe051ea5f` | Signed SAML plus assertion-replay migration | Real, not in `dev`. Migration number `0014` collides with the five-country migration. Adds a dependency. |
| `fix/session-revocation-all-shapes` | `05c60b0bf` | Revoke every session shape on reset and GDPR erasure | Small, tested, best near-term merge. |
| `feat/agent-config-guard`, `feat/cfo-dashboard-story-panels` | tip commits | Tooling guard; dashboard story grid | Small, not financial. |

Obsolete relative to `dev`: `fix/codex-readiness-auth`, `fix/cursor-readiness-build`, `fix/payment-event-safety`, `chore/agent-sdlc-adapters`, `origin/review/reconciliation-atomicity-20260911`, `origin/cleanup/production-focused-dead-code`.

Historical code that **landed and was later removed** from the tree that became `dev`/`main`:

- 13-week cash tab: added `69b8f6b3d` (2025-10-08), replaced `2a2caeedb` (2025-10-11).
- Data room: present in late 2025, removed `7d8ac9329` / `d6a8c5dbc` (2026-02/03).
- M&A intelligence feature: removed `55a422f95` (2026-01-14).

Fourteen customer financial and HR files under `uploads/<uuid>/data-room/` are still **tracked** on `dev` and `main`.

## F. What is implemented differently?

- Financial truth is uploaded statement JSON plus a single-pair transaction table, not `JournalEntry` / `FinancialFact` / `FinancialState`.
- The calculation “graph” is hand-written projection functions, not a typed DAG (`INPUT`, `FORMULA`, `FX`, `DEBT_SCHEDULE`, …).
- Scenarios are three hardcoded cases (`conservative`, `base`, `aggressive`), not cloned immutable scenarios over a published state.
- Publication is `draft → published` for review packages, and a freeze flag for board packs. It is not `DRAFT → VALIDATED → REVIEW → APPROVED → PUBLISHED`.
- Tenant scope is `companyId` in application code. There is no `tenant_id` and no Postgres row-level security.
- Excel is a file utility.
- M&A is a token handoff to NexaDeals, not an in-app lifecycle.
- GAAP vs IFRS is a label. Both standards share chart ranges.
- AI is a read-only copilot over SQL-built context, not a gateway with retrieval, validators, and approval-gated mutation tools.

## G. What is dangerous?

| ID | Severity | Issue |
| --- | --- | --- |
| C1 | CRITICAL | Fourteen customer bank, statement, and HR files are committed under `uploads/.../data-room/`. |
| C2 | CRITICAL | `POST /api/cfo/projections/save` stores client `projectionData` unless `PROJECTION_STRICT_SAVE=true` (`projections.routes.ts`). Server authority can be disabled outside production and via `?serverCalc=0`. |
| C3 | CRITICAL | Posted `transactions` rows are updated and hard-deleted. No reversal. Deletes do not check period lock. |
| H1 | HIGH | GL balances sum `amount` across currencies. Upload FX conversion is explicitly unsupported. |
| H2 | HIGH | Debt instruments load by `userId` into projections (`projectionCalculateService.ts`), not strictly by company. |
| H3 | HIGH | On `POST /transactions`, a learned pattern or model suggestion with confidence above 0.7 can replace the accounts the user chose, and the replacement is not re-validated. |
| H4 | HIGH | Marketing/pricing text claims multi-entity consolidation and 13-week cash flow. Those engines are absent. |
| H5 | HIGH | Audit `beforeState` / `afterState` are always null. Audit writes can fail without failing the mutation. No DB immutability on `audit_logs`. |
| H6 | HIGH | Object lookups by id then authorize (`getTransactionById` ignores `companyId`). Safe only where every route re-checks. |
| M1 | MEDIUM | Approval columns (`requireApprovalAbove`, `dualAuthorization`) are stored and not enforced. |
| M2 | MEDIUM | In-memory webhook idempotency is not durable across restarts or PM2 workers. |
| M3 | MEDIUM | Backup restore is unproven. About eleven Postgres suites skip in CI because their database URLs are unset. |

## H. What should be consolidated?

Do not pick a winner from filenames. Criteria: tested, used, aligned to V3–V7, and present on `dev`.

| Competing implementations | Recommendation |
| --- | --- |
| CFO upload lane vs GL lane | Keep both only as **inputs**. Add one published financial state they both feed. Do not let either become the kernel by default. |
| Server projection calculate vs client calculate/save | One execution path: server calculate, client displays. Turn strict save on and remove the client-truth save. |
| `audit/global-financial-engine-2026-07` projection authority vs current `dev` engines | Port the authority, fiscal, capex, DCF, and citation fixes onto current engines. Do not replace `dev` with the July tree. |
| `feat/guided-cfo-workspace` ledger policy vs current `journalPosting.ts` | Review and port posting/close policy. Do not take the branch wholesale while it tracks customer files. |
| Session auth on `dev` vs SAML branch | Keep session auth. Merge SAML only after dependency approval and migration renumber. |
| Removed data room vs NexaDeals handoff | Do not resurrect the deleted data room as the V10 design. Specify a new evidence ACL on top of object storage. |
| Book-equity-as-EV in weighted valuation vs DCF equity bridge | Keep DCF and LBO math. Stop treating book equity as an enterprise-value method. |

## I. What should be built next?

Dependency-aware sequence. Do not start V13 diligence before a versioned state exists.

1. Remove tracked customer files from Git history planning (security), and stop tracking `uploads/`.
2. Make projection persistence server-authoritative on every environment.
3. Freeze posted GL history: reversals, period checks on every mutation, audit before/after.
4. Define the canonical financial state and stop in-place replacement of published statements.
5. Port the July financial-authority fixes (DCF, fiscal periods, capex, covenants, AI citations) with golden tests.
6. FX policy that fails closed, then translation. No silent rate of 1 for missing rates (the code already avoids that for the identity pair only).
7. Only then: 13-week cash, normalization ledger with approval, QoE bridge, diligence ACL, Excel add-in.

## J. What is required before production?

A production gate against **this** architecture, not against a claim that V13 is built:

1. Customer documents are not in Git. Restore from backup has been exercised.
2. `PROJECTION_STRICT_SAVE` is on, and client grids are not accepted as books or forecasts.
3. Posted journals cannot be edited or deleted. Closed periods reject every mutation, including delete and recurring post.
4. Cross-company debt cannot enter a projection. Currency mismatch cannot be summed.
5. AI cannot change accounts or publish numbers without a human confirmation that re-validates the posting.
6. Pricing copy matches shipped behavior.
7. Postgres integration suites that protect payments, reports, and LBO versions run in CI.
8. Independent review of financial formula changes, with `pnpm test`, `pnpm run test:golden`, and `pnpm run guard:all` recorded. This audit did not re-run those suites.

**Distance to the target picture** (AI over a financial-intelligence layer over a deterministic kernel over a data foundation): the data foundation and the intelligence layer are partial and real. The kernel in the middle is the missing structural piece. AI is already mostly kept off the ledger, which matches the spec’s most important safety rule, with the categorization exception above.

## How this audit was done

- All 27 specification PDFs were text-extracted. V3, V4, V5, and V13 contain the substantive contracts. V6–V12 are two-page construction outlines. V2 documents are one page, and bodies are shifted relative to filenames (see `01_SPECIFICATION_INVENTORY.md`).
- Git: `git branch -a`, `git tag` (empty), `git log --all`, and per-branch `main...branch` comparisons. No checkout.
- Code evidence from `dev` at `426751887`, with branch-only capabilities called out. Local uncommitted edits (`App.tsx`, `moduleRegistry.ts`, `echartsCore.ts`, `utils.ts`, `server/vite.ts`) were not treated as shipped behavior.
- Graphify was queried before code search. Findings were checked against source paths cited in the later reports.

## Where to read next

| If you need | Read |
| --- | --- |
| Spec quality and cumulative requirements | `01_SPECIFICATION_INVENTORY.md` |
| What each branch actually adds | `03_BRANCH_ANALYSIS.md` |
| Requirement-by-requirement status | `04_V1_V13_TRACEABILITY_MATRIX.md` and `requirements_traceability.csv` |
| Whether a kernel exists | `05_FINANCIAL_KERNEL_AUDIT.md` |
| What to build | `22_GAP_BACKLOG.md` and `24_IMPLEMENTATION_ROADMAP.md` |
| Production yes/no | `25_FINAL_READINESS_REPORT.md` |
