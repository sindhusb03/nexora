# 16 — Testing Audit

Tests are numerous. They do not prove the V3 golden catalog.

## Layout on `dev`

About 326 test files: roughly 280 unit and regression tests under `tests/`, 1 file in `tests/golden/`, 5 in `tests/contracts/`, 5 in `tests/security/`, 18 integration files, plus Playwright under `e2e/`.

CI (`.github/workflows/ci.yml`) runs format, lint, `guard:all`, typecheck, build, unit tests with Postgres 15, golden/contract, security, migration check, and a critical e2e set. This audit did not re-run that pipeline. The risk register and workflow files are the evidence for what CI executes.

## What financial tests actually assert

| Invariant | Where | Proves |
| --- | --- | --- |
| Assets = liabilities + equity, cash roll, retained earnings roll-forward | `tests/threeStatementIntegrity.regression.test.ts` | Projection engine outputs |
| Accounting books helpers, year-end close shape, period block helper | `tests/accountingBooksIntegrity.test.ts` | Pure functions, not the HTTP delete path |
| Cash flow statement integrity | `tests/cashFlowReportIntegrity.regression.test.ts` | Report builder |
| DCF formulas | `tests/dcfFormulaIntegrity*` | DCF function |
| LBO sources = uses | `tests/lboEngine.test.ts` | LBO closing |
| Debt annuity safety | `tests/debtAnnuitySafety*` | Annuity helper |
| Reconciliation match atomicity | `tests/reconciliationAtomicity*` | Match/unmatch |
| Projection calculate contract | `tests/contracts/projection-calculate.contract.test.ts` | Response shape |
| Cross-tenant access | `tests/security/crossTenantAccess.security.test.ts` | Mostly mocked storage |

`tests/golden/financial-baseline.golden.test.ts` snapshots ratios and helpers, including helpers that live under `tests/utils/financialCalculations.ts`. It does not snapshot a full three-statement model, and it does not assert consolidation or FX. `pnpm run test:golden` also runs the contract tests. That is a thin golden gate relative to V3 section 10.

## Specified fixtures with no test

- Consolidation: components + eliminations + NCI.
- FX: rate selection, translation, remeasurement, rounding.
- Scenario: base row unchanged after downside (only partially true by table separation, not a published-state test).
- V13: `V13-ONB-001`, `V13-CASH-001`–`003`, `V13-NORM-001`–`002`, `V13-QOE-001`–`002`, `V13-DD-001`–`002`, `V13-TXN-001`, `V13-AI-001`.
- 10k-node performance.
- Property tests for ledger conservation under random journals. Not found as a property suite.
- Mutation testing. Not found.
- Backup restore against real object storage. `tests/backupRestoreExercise.test.ts` mocks S3.

## CI skips

About eleven Postgres suites (payments, report safety, retention, password reset, background job lease, LBO versions, webhook ordering) run only if `PAYMENT_SAFETY_TEST_DATABASE_URL`, `REPORT_SAFETY_TEST_DATABASE_URL`, or `LBO_TEST_DATABASE_URL` is set. Those variables are not set in `ci.yml`. The suites skip. `feat/guided-cfo-workspace` has a commit that requires a disposable database for CI. That commit is not on `dev`.

## July branch

`audit/global-financial-engine-2026-07` adds `tests/audit/*.recompute.ts` files that recompute DCF, capex, ratios, and covenants. They are the closest thing to an expanded golden set, and they are unmerged. They still do not cover consolidation or V13.

## Verdict

Tests prove a useful slice of projection identity, DCF arithmetic, and LBO sources and uses when the server functions run. They do not prove a kernel, and they do not run the database safety suites on every CI build. Counting tests would overstate financial readiness.
