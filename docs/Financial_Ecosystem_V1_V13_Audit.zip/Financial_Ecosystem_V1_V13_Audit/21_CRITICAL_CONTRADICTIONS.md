# 21 — Specification versus Code Contradictions

Each item is a place the code violates a rule the specifications state in readable text.

## CRITICAL

### C1. Customer financial documents are in Git

Spec: V10 documents are access-controlled artifacts. V1 says developers do not have standing access to bank and payroll data.

Evidence: `git ls-files uploads` lists 14 files under `uploads/a5628d05-1875-46d0-b976-ea8da0fc7f73/data-room/`, including a bank-statement PDF, income statements, balance sheets, and HR employee CSVs. Present on `dev` and `main`.

### C2. The client can be the forecast system of record

Spec: V3/V7 calculations are reproducible server runs. V5 says the browser does not own financial truth. Repository contract: client sends inputs only.

Evidence: `PROJECTION_STRICT_SAVE` is `process.env.PROJECTION_STRICT_SAVE === "true"` in `projections.routes.ts`. The save handlers persist `req.body` projection data when that flag is false. `?serverCalc=0` and a non-production default turn server authority off.

### C3. Posted accounting history is mutable

Spec: V3 “Posted entries are never updated or deleted. Corrections are reversals.”

Evidence: transaction update and hard delete in storage and accounting routes. No reversal type. No database trigger.

## HIGH

### H1. Mixed currencies are added together

Spec: V3 missing rates block calculation. V2 body: no silent 1.0 fallback. Original currency is preserved and derived amounts use a rate set.

Evidence: upload path blocks mismatch (`financialStatementCurrency.ts`). GL sums `transactions.amount` without conversion. `baseAmount` is not populated by the server. This is not a silent rate of 1. It is a silent “already the same currency” assumption.

### H2. Debt crosses companies inside a forecast

Spec: tenant isolation on every read.

Evidence: `getDebtInstruments(userId)` from `projectionCalculateService.ts`.

### H3. A model can change the journal before it is stored

Spec: V1 and V9: AI proposes; posting follows validation and approval. “LLM never writes directly to the database” (V2 body filed under the security-titled PDF).

Evidence: `POST /transactions` replaces accounts from a learned pattern or from `categorizeTransaction` when confidence is above 0.7, unless `aiCategorized` was already set. The new accounts are not passed through the same validation again. The write is application code, not the model holding a database credential. The effect is still an unapproved mutation.

### H4. Marketing describes unbuilt engines

Spec: do not claim a control you do not operate. This is a product contradiction with V3 consolidation and V13 cash.

Evidence: `seedPricingPlans.ts` (“multi-entity consolidation”), `blogArticleContent.ts` (intercompany eliminations), `remaining-legacy.routes.ts` (“13-week cash flow”).

### H5. Audit does not record the change

Spec: V6 audit event has actor, command, object, and is append-only. V3 lineage includes actor and versions.

Evidence: `beforeState` and `afterState` set null in `auditLogger.ts`. Failures are swallowed. Retention deletes rows.

### H6. In-place republish of statements

Spec: published versions are immutable.

Evidence: `ingestionService.ts` comment and update of `uploaded_financial_statements` when replacing.

### H7. Book equity can be treated as enterprise value

Spec: V7 equity value = EV − net debt + non-operating assets − other claims. Book value of equity is not an EV method.

Evidence: weighted valuation path in `modelingEvaluateService.ts`.

## MEDIUM

### M1. Approval flags do nothing

`requireApprovalAbove` and `dualAuthorization` are stored on `companies` and not read by posting.

### M2. GAAP versus IFRS is a label

`reportingStandard` does not change recognition. V12 says a second basis must not corrupt facts. Here there is only one basis, so facts are not corrupted, and the field over-claims.

### M3. Webhook idempotency is process-local

`integrations.routes.ts` uses an in-memory map. V6 requires idempotent consumers across retries and restarts.

### M4. Fetch-then-authorize

Spec: authorization at the data boundary. Code loads by primary key and checks company afterward. Safe only by convention.

### M5. Excel export is static values

Spec: Excel is a controlled client. Code downloads a workbook of numbers with no version binding.

## LOW

### L1. V6 error-code catalog is unused

Behavior sometimes matches the intent (period block, currency conflict) under different names.

### L2. Engine version is a hand-bumped semver

Reproducibility wants a build hash. `1.2.0` does not identify the git commit.

## Not contradictions

AI chat tools do not insert journals. SAML fail-closed on `dev` matches “do not run unverified SSO.” Absence of an autonomous agent matches V4’s “explicitly later.” A modular monolith matches V5’s permission to start that way, provided boundaries exist. Those boundaries are the gap, and they are recorded as missing architecture rather than as a forbidden microservice.
