# 11 — Excel Audit

V8 section 4 and the V2 Excel body (filed under the AI-titled PDF) require Excel to be a first-class client: sign-in, tenant context, refresh of an authorized version, assumption edits as proposals, write-back through validation, conflict detection, lineage, and untrusted macros.

## What was searched

No `Office.onReady`, `Excel.run`, or Office add-in `manifest.xml` on `dev` or in branch history that the branch audit searched. `feat/guided-cfo-workspace` adds spreadsheet **import interpretation**, which parses a file. It does not host an add-in.

## What exists

| Behavior | Location | Spec match |
| --- | --- | --- |
| Export statements and projections to XLSX | `client/src/components/financial/utils/exportExcel.ts`, `exportProjectionToExcel.ts` | Export utility |
| Export valuation and LBO | `valuation/utils/valuationExport.ts`, `valuation/lbo/export.ts` | Export utility |
| Cell contents | Static numbers (`exportProjectionToExcel.ts`), not live formulas bound to a version | Not a controlled model |
| Import | `server/services/excelParser.ts`; Google Sheets read in categorization routes | Import utility |
| Write-back | None | Missing |
| Conflict resolver | None | Missing |
| Lineage in the workbook | None | Missing |
| Auth inside Excel | None. The browser session exports a file. | Missing |

Playwright `e2e` includes a canary Excel path. That exercises file import/export, not Office.js.

## Verdict

Excel is an export/import utility. Status against V8: NOT_IMPLEMENTED for the add-in, with a real file bridge at about 10% completeness (R027). Building an add-in before a lineage API and strict server save would make the workbook another source of truth, which V2 explicitly forbids.
