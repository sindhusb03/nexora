# 04 — V1–V13 Traceability Matrix

Baseline: branch `dev` at `426751887`, unless the Branch column names another branch.
Completeness is 0–100 for that requirement as specified. A matching filename is not enough.
Weighted mean completeness across these 86 rows: **31.9%**.

Status counts:
- PARTIAL: 35
- NOT_IMPLEMENTED: 20
- IMPLEMENTED_WITH_GAPS: 18
- IMPLEMENTED_DIFFERENTLY: 8
- IMPLEMENTED: 3
- DEPRECATED: 2

Machine-readable source: `requirements_traceability.csv`.

| ID | Requirement | Version | Status | % | Priority | Domain |
| --- | --- | --- | --- | ---: | --- | --- |
| R001 | Business Owner, CFO, FA, IB, Board, Platform Admin role model | V1 | IMPLEMENTED_DIFFERENTLY | 40 | P1 | Security |
| R002 | AI proposes journal; posting requires validation and approval | V1 | IMPLEMENTED_WITH_GAPS | 45 | P0 | AI |
| R003 | Owner onboarding: company, jurisdiction, currency, fiscal year, connect sources, approve | V1 | PARTIAL | 45 | P1 | Onboarding |
| R004 | Drill from board KPI to statement, GL, transaction, source document | V1 | PARTIAL | 30 | P2 | Modeling |
| R005 | Deal workspace from acquire intent through board approval | V1 | PARTIAL | 15 | P1 | M&A |
| R006 | Platform admin has no default access to customer financials | V1 | IMPLEMENTED_WITH_GAPS | 55 | P1 | Security |
| R007 | Canonical ontology: tenant, entity, period, fact, scenario, valuation | V2 | IMPLEMENTED_DIFFERENTLY | 35 | P0 | Financial Kernel |
| R008 | Published financial versions immutable | V2 | IMPLEMENTED_WITH_GAPS | 40 | P0 | Financial Kernel |
| R009 | Balanced journals, atomic post, reversals not destructive edits | V2 | IMPLEMENTED_WITH_GAPS | 35 | P0 | Accounting |
| R010 | Period close rejects posting | V3 | IMPLEMENTED_WITH_GAPS | 50 | P0 | Accounting |
| R011 | Idempotent replay of postings | V2 | PARTIAL | 40 | P1 | Accounting |
| R012 | Consolidation pipeline: perimeter, FX, eliminate, NCI | V3 | NOT_IMPLEMENTED | 0 | P1 | Consolidation |
| R013 | Retain transaction currency; versioned rates; no silent 1.0 | V3 | PARTIAL | 25 | P0 | FX |
| R014 | Typed calculation DAG, cycle check, incremental invalidation | V3 | IMPLEMENTED_DIFFERENTLY | 30 | P1 | Financial Kernel |
| R015 | Decimal precision and explicit rounding in analytical calc | V3 | IMPLEMENTED_WITH_GAPS | 40 | P0 | Financial Kernel |
| R016 | Lineage from output to source, mapping, engine, approval | V3 | PARTIAL | 35 | P0 | Financial Kernel |
| R017 | Publication state machine through APPROVED | V3 | IMPLEMENTED_DIFFERENTLY | 35 | P1 | Financial Kernel |
| R018 | Golden fixtures: 3-statement, consolidation, FX, DCF, debt, LBO, scenario, tenant | V3 | PARTIAL | 40 | P0 | Testing |
| R019 | Domain events with correlation and causation | V3 | PARTIAL | 25 | P1 | Infrastructure |
| R020 | V4 loop: import, map, reconcile, state, forecast, scenario, valuation, board | V4 | IMPLEMENTED_WITH_GAPS | 55 | P0 | Modeling |
| R021 | Chart of accounts mapping with quarantine | V4 | PARTIAL | 50 | P1 | Onboarding |
| R022 | Reconciliation of import totals | V4 | PARTIAL | 45 | P1 | Accounting |
| R023 | Three-statement model server-authoritative | V4 | IMPLEMENTED_WITH_GAPS | 60 | P0 | Forecasting |
| R024 | Scenarios isolated from base actuals | V4 | IMPLEMENTED_WITH_GAPS | 55 | P1 | Forecasting |
| R025 | DCF from pinned versions with sensitivity | V4 | IMPLEMENTED_WITH_GAPS | 65 | P1 | Valuation |
| R026 | Board pack from published state with lineage | V4 | IMPLEMENTED_WITH_GAPS | 60 | P1 | Modeling |
| R027 | Excel refresh, trace, controlled write-back | V4 | NOT_IMPLEMENTED | 10 | P1 | Excel |
| R028 | Grounded AI Q&A with citations, no direct publish | V4 | PARTIAL | 40 | P1 | AI |
| R029 | Service ownership boundaries inside a modular monolith | V5 | IMPLEMENTED_DIFFERENTLY | 45 | P2 | Infrastructure |
| R030 | PostgreSQL for state; object storage for documents | V5 | IMPLEMENTED | 70 | P0 | Infrastructure |
| R031 | Search or vector index for evidence | V5 | NOT_IMPLEMENTED | 0 | P2 | AI |
| R032 | Queue for heavy calculation | V5 | PARTIAL | 40 | P2 | Infrastructure |
| R033 | IaC: Terraform or Kubernetes | V5 | IMPLEMENTED_DIFFERENTLY | 25 | P3 | Infrastructure |
| R034 | Environments local/dev/staging/pilot/prod with separated secrets | V5 | PARTIAL | 35 | P2 | Infrastructure |
| R035 | V6 schema: journal header, facts, fx rate sets, model nodes, calc runs | V6 | NOT_IMPLEMENTED | 15 | P0 | Financial Kernel |
| R036 | V6 API /v1/imports through /v1/lineage | V6 | IMPLEMENTED_DIFFERENTLY | 30 | P2 | API |
| R037 | Error codes FIN_PERIOD_CLOSED, FIN_UNBALANCED_JOURNAL, FX_RATE_MISSING, CALC_CYCLE_DETECTED | V6 | PARTIAL | 20 | P2 | API |
| R038 | OpenAPI and JSON Schema validated in CI | V6 | PARTIAL | 25 | P2 | API |
| R039 | Migrations from empty database | V6 | IMPLEMENTED | 70 | P2 | Infrastructure |
| R040 | V7 three-statement identities | V7 | IMPLEMENTED | 75 | P0 | Modeling |
| R041 | Identical inputs and engine build reproduce outputs | V7 | PARTIAL | 45 | P1 | Financial Kernel |
| R042 | Failed calculation cannot publish | V7 | PARTIAL | 40 | P0 | Forecasting |
| R043 | V8 surfaces: dashboard, connections, mapping, statements, model, scenarios, valuation, board, lineage, approvals | V8 | PARTIAL | 60 | P1 | Modeling |
| R044 | Import UX connect, profile, map, dry run, reconcile, approve, publish | V8 | PARTIAL | 40 | P1 | Onboarding |
| R045 | AI gateway: classifier, retrieval planner, tool router, validator, audit | V9 | IMPLEMENTED_DIFFERENTLY | 30 | P1 | AI |
| R046 | Tool authority: read vs proposal vs approval-gated post | V9 | PARTIAL | 45 | P1 | AI |
| R047 | Authorization filter before ranking | V9 | PARTIAL | 40 | P1 | AI |
| R048 | Prompt injection: documents are data | V9 | NOT_IMPLEMENTED | 15 | P1 | AI |
| R049 | AI evaluation: groundedness, numeric accuracy, cross-tenant, cost | V9 | PARTIAL | 20 | P2 | AI |
| R050 | Every tool call audited with argument hash and policy decision | V9 | NOT_IMPLEMENTED | 15 | P1 | AI |
| R051 | Deal stages origination through closed | V10 | NOT_IMPLEMENTED | 10 | P1 | M&A |
| R052 | Data room documents immutable, hashed, ACL, audited download | V10 | DEPRECATED | 0 | P0 | Data Room |
| R053 | Diligence request to finding with evidence | V10 | NOT_IMPLEMENTED | 0 | P1 | Diligence |
| R054 | Valuation case pinned; purchase price stored separately | V10 | PARTIAL | 30 | P2 | Valuation |
| R055 | Signing and closing require approval evidence | V10 | NOT_IMPLEMENTED | 0 | P2 | M&A |
| R056 | Debt schedule identity and interest policy | V11 | IMPLEMENTED_WITH_GAPS | 60 | P1 | Debt |
| R057 | Covenants from financial state | V11 | PARTIAL | 25 | P1 | Debt |
| R058 | Cap table ledger, atomic transfer, immutable published table | V11 | PARTIAL | 45 | P1 | Cap Table |
| R059 | Fundraising close updates ownership only when approved | V11 | PARTIAL | 20 | P1 | Equity |
| R060 | LBO sources = uses, debt paydown, MOIC, IRR | V11 | IMPLEMENTED_WITH_GAPS | 70 | P2 | LBO |
| R061 | Waterfall preferences and participation | V11 | NOT_IMPLEMENTED | 10 | P2 | Equity |
| R062 | IFRS, US GAAP, local GAAP as policy over facts | V12 | NOT_IMPLEMENTED | 10 | P3 | Compliance |
| R063 | Tax isolated from core facts | V12 | PARTIAL | 30 | P3 | Compliance |
| R064 | Functional, transaction, presentation currency | V12 | PARTIAL | 25 | P1 | FX |
| R065 | i18n: locale is not an identifier; Unicode; explicit currency | V12 | PARTIAL | 30 | P3 | Compliance |
| R066 | Data residency and region placement | V12 | NOT_IMPLEMENTED | 0 | P3 | Compliance |
| R067 | SSO, MFA, RBAC | V12 | IMPLEMENTED_WITH_GAPS | 65 | P1 | Security |
| R068 | SOC2/SOX-oriented evidence: SoD, immutable audit | V12 | PARTIAL | 35 | P1 | Security |
| R069 | DR RPO 15 min RTO 60 min exercised | V12 | PARTIAL | 20 | P1 | Infrastructure |
| R070 | Observability with financial-impact alerts | V12 | PARTIAL | 30 | P2 | Infrastructure |
| R071 | Onboarding state machine to FINANCIAL_STATE_READY | V13 | NOT_IMPLEMENTED | 20 | P1 | Onboarding |
| R072 | Entity hierarchy, ownership, effective dates | V13 | NOT_IMPLEMENTED | 5 | P1 | Consolidation |
| R073 | Opening balances balanced and approved | V13 | PARTIAL | 25 | P1 | Onboarding |
| R074 | 13-week roll-forward and scenario isolation | V13 | DEPRECATED | 0 | P1 | Cash Flow |
| R075 | Liquidity alerts from headroom policy | V13 | PARTIAL | 20 | P2 | Cash Flow |
| R076 | Normalization ledger: proposed until approved, evidence, reversible | V13 | IMPLEMENTED_WITH_GAPS | 30 | P1 | Normalization |
| R077 | QoE: revenue quality, EBITDA bridge, NWC, net debt, findings | V13 | NOT_IMPLEMENTED | 10 | P1 | QoE |
| R078 | Diligence workstreams and evidence ACL | V13 | NOT_IMPLEMENTED | 0 | P1 | Diligence |
| R079 | Transaction bridge EV to equity with NWC and net debt versions | V13 | PARTIAL | 25 | P1 | Valuation |
| R080 | V13 APIs for onboarding, cash, normalization, qoe, diligence, bridges | V13 | NOT_IMPLEMENTED | 0 | P2 | API |
| R081 | V13 golden tests ONB, CASH, NORM, QOE, DD, TXN, AI | V13 | NOT_IMPLEMENTED | 0 | P1 | Testing |
| R082 | Tenant isolation tests and company scope on mutations | V3 | IMPLEMENTED_WITH_GAPS | 60 | P0 | Security |
| R083 | Encryption of secrets and upload controls | V2 | IMPLEMENTED_WITH_GAPS | 60 | P1 | Security |
| R084 | Calculation benchmark harness 10k nodes | V3 | NOT_IMPLEMENTED | 0 | P3 | Testing |
| R085 | Two accounting bases without mutating canonical facts | V12 | NOT_IMPLEMENTED | 0 | P3 | Compliance |
| R086 | AI cannot directly publish financial state | V13 | IMPLEMENTED_WITH_GAPS | 70 | P0 | AI |

## Evidence by requirement

### R001 — Business Owner, CFO, FA, IB, Board, Platform Admin role model
- Spec: V1 user flows ss 5-16
- Code: `shared/roles.ts; shared/schema.ts company membership` on `dev`
- Evidence: Team roles owner/admin/reviewer/auditor/viewer. No CFO, analyst, banker, or board role.
- Gap: Persona model is navigation and team RBAC, not the V1 role catalog.

### R002 — AI proposes journal; posting requires validation and approval
- Spec: V1 s15
- Code: `server/services/chatService.ts; server/accounting/routes.ts` on `dev`
- Evidence: Chat tools are read-only. Categorize path can replace accounts before post when confidence > 0.7.
- Gap: No approval gate on the account replacement.

### R003 — Owner onboarding: company, jurisdiction, currency, fiscal year, connect sources, approve
- Spec: V1 s2
- Code: `server/routes/modules/cfo-companies.routes.ts; GettingStartedPage.tsx` on `dev`
- Evidence: CFO onboard and simplified-onboard exist. Default 81-account COA on accounting create.
- Gap: No readiness certificate. Connectors for QB/Xero are beta and not enabled for workspace types.

### R004 — Drill from board KPI to statement, GL, transaction, source document
- Spec: V1 s6
- Code: `client/src/components/financial/trace/` on `dev`
- Evidence: Static formula popovers by line label.
- Gap: No source-cell to journal drill.

### R005 — Deal workspace from acquire intent through board approval
- Spec: V1 s4 and s8
- Code: `server/services/platformLinkService.ts` on `dev`
- Evidence: NexaDeals handoff tokens and platform_deal_links.
- Gap: In-app deal lifecycle absent. Data room removed.

### R006 — Platform admin has no default access to customer financials
- Spec: V1 s12
- Code: `server/middleware/adminImpersonation.ts; authorizationService.ts` on `dev`
- Evidence: Company access is explicit. Impersonation exists.
- Gap: Support access is not a time-bound approval workflow as V12 specifies.

### R007 — Canonical ontology: tenant, entity, period, fact, scenario, valuation
- Spec: V2 doc 02 body; V3 s2
- Code: `shared/schema.ts` on `dev`
- Evidence: companies, periods, uploaded statements, saved projections, valuation models.
- Gap: No legal-entity aggregate, no versioned FinancialFact, no tenant_id.

### R008 — Published financial versions immutable
- Spec: V2/V3 s9
- Code: `ingestionService.ts; boardPackLifecycle.ts` on `dev`
- Evidence: Board packs freeze. Review package draft to published is conditional.
- Gap: Upload republish replaces parsedData in place. GL rows are mutable.

### R009 — Balanced journals, atomic post, reversals not destructive edits
- Spec: V2 doc 03 body; V3 s4
- Code: `server/accounting/journalPosting.ts; transactions table` on `dev`
- Evidence: Single-pair debit/credit rows. Decimal posting helpers. Idempotency on invoice/bill payments.
- Gap: No multi-line journal. Update and hard delete exist. No reversal type.

### R010 — Period close rejects posting
- Spec: V3 s4
- Code: `fiscalPeriodStatus; accounting routes` on `dev`
- Evidence: isPeriodPostingBlocked on create, update, bulk import.
- Gap: Delete, recurring process, and some invoice paths skip the check. Lock status is weakly validated.

### R011 — Idempotent replay of postings
- Spec: V2 doc 03 body; V6 import_idempotency
- Code: `financialOperationReceipts` on `dev`
- Evidence: Idempotency-Key on invoice and bill payments.
- Gap: Not on general journals. Integration webhook dedupe is in-memory.

### R012 — Consolidation pipeline: perimeter, FX, eliminate, NCI
- Spec: V3 s5; V7 s6
- Code: `companies.subsidiaries jsonb; consolidatedReporting flag` on `dev`
- Evidence: Flag and string list only. Classification labels mention intercompany.
- Gap: No ownership graph, elimination, or NCI. Pricing copy claims it.

### R013 — Retain transaction currency; versioned rates; no silent 1.0
- Spec: V3 s6; V2 doc 05 body
- Code: `financialStatementCurrency.ts; exchangeRateSync.ts` on `dev`
- Evidence: Upload path blocks currency mismatch. Identity rate 1 only when currencies match.
- Gap: No translation, CTA, average/closing stores. GL sums mixed currencies. exchange rate getter ignores companyId.

### R014 — Typed calculation DAG, cycle check, incremental invalidation
- Spec: V3 s7; V7 s5
- Code: `shared/projections/*` on `dev`
- Evidence: Imperative growth, scenario, and KPI engines.
- Gap: No graph, no cycle detection, no descendant-only recalc.

### R015 — Decimal precision and explicit rounding in analytical calc
- Spec: V3 s11
- Code: `shared/projections; journalPosting.ts` on `dev`
- Evidence: GL uses decimal.js. Projections use JS numbers and toFixed.
- Gap: Float forecasts. Tolerances of 1.0 and 0.5 percent.

### R016 — Lineage from output to source, mapping, engine, approval
- Spec: V3 s8
- Code: `projectionCalculateService.attachLineage; trace maps` on `dev`
- Evidence: Engine version, fingerprints, review receipt snapshot.
- Gap: Client trace is static. Mappings are not versioned. Cannot answer why a number is 42.7 end to end.

### R017 — Publication state machine through APPROVED
- Spec: V3 s9
- Code: `reviewPackages; boardPackLifecycle` on `dev`
- Evidence: draft to published; board publishedAt freeze.
- Gap: No VALIDATED, REVIEW, APPROVED, maker-checker. Approval columns unused.

### R018 — Golden fixtures: 3-statement, consolidation, FX, DCF, debt, LBO, scenario, tenant
- Spec: V3 s10; V7 s8
- Code: `tests/threeStatementIntegrity.regression.test.ts; tests/lboEngine.test.ts; tests/golden` on `dev`
- Evidence: 3-statement, cash, RE, DCF formula, LBO sources=uses tests exist.
- Gap: Single thin golden file. No consolidation or FX translation fixture.

### R019 — Domain events with correlation and causation
- Spec: V3 s12; V6 s5
- Code: `audit_logs.correlationId` on `dev`
- Evidence: HTTP audit middleware stores correlation id from header.
- Gap: No JournalPosted or CalculationCompleted event log. before/after state always null.

### R020 — V4 loop: import, map, reconcile, state, forecast, scenario, valuation, board
- Spec: V4 s3
- Code: `upload, projections, valuation, board packs` on `dev`
- Evidence: The screens and services exist across two lanes.
- Gap: Not one versioned financial state. Client can save forecast grids.

### R021 — Chart of accounts mapping with quarantine
- Spec: V4 epic A; V13 s3
- Code: `cfo_line_item_mappings; account_mappings` on `dev`
- Evidence: Mapping tables and categorization exist.
- Gap: No mapping version, no 100 percent mapped-or-quarantined publish gate.

### R022 — Reconciliation of import totals
- Spec: V4 epic A
- Code: `server/accounting/reconciliation.ts; accountingCfoReconciliationService.ts` on `dev`
- Evidence: Bank match is atomic. CFO vs GL comparison is read-only.
- Gap: Close package uses live bank balance as statement balance.

### R023 — Three-statement model server-authoritative
- Spec: V4 epic C; AGENTS.md
- Code: `projectionCalculateService.ts; projections.routes.ts` on `dev`
- Evidence: Server calculate, 422 on broken tie-out, fingerprints.
- Gap: PROJECTION_STRICT_SAVE defaults off. Client engines run when server authority is off.

### R024 — Scenarios isolated from base actuals
- Spec: V4 epic D; V7
- Code: `scenarioCalculations.ts; saved_projections` on `dev`
- Evidence: conservative/base/aggressive. Actuals are not overwritten.
- Gap: Not cloned assumption sets. Only base is tie-out checked. No publish state.

### R025 — DCF from pinned versions with sensitivity
- Spec: V4 epic E; V7 s7
- Code: `shared/valuation/dcfCalculations.ts; modelingEvaluateService.ts` on `dev`
- Evidence: FCFF, Gordon TV, WACC/CAPM, sensitivity in LBO. July branch has stricter timing.
- Gap: Equity bridge is EV-debt+cash only. Weighted method treats book equity as EV.

### R026 — Board pack from published state with lineage
- Spec: V4 epic F; V8 s6
- Code: `boardPackLifecycle.ts; boardPackGenerationService.ts` on `dev`
- Evidence: Publish freeze, currency snapshot, PDF.
- Gap: pptx column unused. Numbers are not a kernel state hash.

### R027 — Excel refresh, trace, controlled write-back
- Spec: V4 P1; V8 s4
- Code: `client export exceljs; server excelParser.ts` on `dev`
- Evidence: XLSX export of static values and CSV/XLSX import.
- Gap: No Office.js, bindings, conflict resolver, or write-back proposal.

### R028 — Grounded AI Q&A with citations, no direct publish
- Spec: V4 epic G; V9
- Code: `cfoBrain/pipeline.ts; chatService.ts` on `dev`
- Evidence: Read-only tools, company-scoped. Keyword evidence score.
- Gap: No RAG, no numeric claim validator on dev. Citation policy is on the July branch only.

### R029 — Service ownership boundaries inside a modular monolith
- Spec: V5 s3
- Code: `server/routes/modules; server/services` on `dev`
- Evidence: Route and service modules.
- Gap: Forecast math, reporting, and ingestion are not isolated packages. UI can calculate.

### R030 — PostgreSQL for state; object storage for documents
- Spec: V5 s5
- Code: `shared/schema.ts; server/objectStorage.ts GCS` on `dev`
- Evidence: Postgres is the system of record. GCS and local uploads exist.
- Gap: Customer files also committed to Git.

### R031 — Search or vector index for evidence
- Spec: V5 s5; V9 s4
- Code: `none` on `dev`
- Evidence: No pgvector or embeddings dependency.
- Gap: Structured SQL only.

### R032 — Queue for heavy calculation
- Spec: V5 principles
- Code: `server/services/backgroundJobQueue.ts` on `dev`
- Evidence: Postgres-backed jobs with leases.
- Gap: Projection calculate is synchronous request path. No separate worker class for AI/PDF isolation.

### R033 — IaC: Terraform or Kubernetes
- Spec: V5 repo layout
- Code: `Dockerfile; docker-compose; deploy.yml SSH` on `dev`
- Evidence: Container and PM2 and EC2 deploy.
- Gap: No Terraform, Kubernetes, or Helm.

### R034 — Environments local/dev/staging/pilot/prod with separated secrets
- Spec: V5 s2
- Code: `GitHub production environment; docker-compose.prod.yml` on `dev`
- Evidence: Prod deploy workflow and compose prod file.
- Gap: No staging/pilot topology in repo. Restore unproven.

### R035 — V6 schema: journal header, facts, fx rate sets, model nodes, calc runs
- Spec: V6 s2
- Code: `shared/schema.ts` on `dev`
- Evidence: Nearby tables exist under different names.
- Gap: Specified tables and invariants are absent.

### R036 — V6 API /v1/imports through /v1/lineage
- Spec: V6 s4; V4 s7
- Code: `server/routes/modules/*` on `dev`
- Evidence: Similar capabilities under /api/cfo and /api/accounting.
- Gap: Paths, idempotency, and Expected-Version are not the contract.

### R037 — Error codes FIN_PERIOD_CLOSED, FIN_UNBALANCED_JOURNAL, FX_RATE_MISSING, CALC_CYCLE_DETECTED
- Spec: V6 s4
- Code: `various HTTP errors` on `dev`
- Evidence: Some domain errors such as FINANCIAL_SOURCE_CURRENCY_CONFLICT.
- Gap: Catalog not implemented. Cycle code cannot fire because there is no graph.

### R038 — OpenAPI and JSON Schema validated in CI
- Spec: V6 s7; V2
- Code: `server/lib/swagger.ts; docs/api/openapi.snapshot.json` on `dev`
- Evidence: Hand-written swagger shell and a snapshot script.
- Gap: apis array empty. Drift is not a merge gate.

### R039 — Migrations from empty database
- Spec: V6 definition of done
- Code: `migrations/0000_init_baseline.sql; server/migrate.ts` on `dev`
- Evidence: Squashed baseline and CI migration check.
- Gap: Branch 0014 numbers collide. No expand-contract policy enforced.

### R040 — V7 three-statement identities
- Spec: V7 s4
- Code: `verifyThreeStatementIntegration; threeStatementIntegrity tests` on `dev`
- Evidence: A=L+E, cash roll, RE roll tested for the projection engine.
- Gap: Does not prove GL or consolidation.

### R041 — Identical inputs and engine build reproduce outputs
- Spec: V7 s9
- Code: `projection_calculate_audit fingerprints; ENGINE_VERSION 1.2.0` on `dev`
- Evidence: Fingerprints stored. Audit insert is best-effort.
- Gap: new Date fallbacks in projection start. Engine version is a manual semver, not a build hash.

### R042 — Failed calculation cannot publish
- Spec: V7 s9
- Code: `projection calculate 422; review package status` on `dev`
- Evidence: Broken three-statement calculate returns 422.
- Gap: Client save can persist grids without that check when strict save is off.

### R043 — V8 surfaces: dashboard, connections, mapping, statements, model, scenarios, valuation, board, lineage, approvals
- Spec: V8 s2
- Code: `client/src pages and components` on `dev`
- Evidence: Most screens exist.
- Gap: Lineage and approvals are thinner than the spec. Connections are limited.

### R044 — Import UX connect, profile, map, dry run, reconcile, approve, publish
- Spec: V8 s5
- Code: `ingestion services; categorization` on `dev`
- Evidence: Upload, map, and review package publish exist.
- Gap: No formal dry-run quarantine reason-code workflow. Silent category replacement exists on GL post.

### R045 — AI gateway: classifier, retrieval planner, tool router, validator, audit
- Spec: V9 s2
- Code: `server/lib/aiClient.ts; cfoBrain/pipeline.ts` on `dev`
- Evidence: Single OpenRouter client. Server-side tool map.
- Gap: No risk classifier, retrieval planner, or output validator.

### R046 — Tool authority: read vs proposal vs approval-gated post
- Spec: V9 s3
- Code: `chatService buildCFOTools` on `dev`
- Evidence: Implemented tools are read-only getters.
- Gap: post_journal and publish tools do not exist. Categorize is a side path.

### R047 — Authorization filter before ranking
- Spec: V9 s4
- Code: `company-scoped SQL in tools` on `dev`
- Evidence: Tools bind session company.
- Gap: No retrieval ranker. IDOR pattern remains fetch-then-check.

### R048 — Prompt injection: documents are data
- Spec: V9 s5
- Code: `piiSanitizer.ts` on `dev`
- Evidence: PII regex redaction only.
- Gap: No injection corpus tests, no tool-arg allowlist beyond the fixed map.

### R049 — AI evaluation: groundedness, numeric accuracy, cross-tenant, cost
- Spec: V9 s7
- Code: `responseQuality.ts keyword score; aiCostTracker.ts` on `dev`
- Evidence: Cost tracking and a keyword score.
- Gap: No eval suite, no numeric compare-to-tool gate on dev.

### R050 — Every tool call audited with argument hash and policy decision
- Spec: V9 s8
- Code: `audit middleware on HTTP mutations` on `dev`
- Evidence: Chat writes history.
- Gap: Tool calls are not an append-only AI audit record.

### R051 — Deal stages origination through closed
- Spec: V10 s2
- Code: `platform handoff; deal_physics tables` on `dev`
- Evidence: Handoff creates an external deal. deal_physics is term modeling.
- Gap: State machine absent. Historical data room removed.

### R052 — Data room documents immutable, hashed, ACL, audited download
- Spec: V10 s4
- Code: `removed; uploads/ still in git` on `dev`
- Evidence: Commits d6a8c5dbc and 7d8ac9329 removed the module.
- Gap: No replacement ACL. Files remain in the repo.

### R053 — Diligence request to finding with evidence
- Spec: V10 s5; V13 s7
- Code: `none` on `dev`
- Evidence: No diligence_request table or routes.
- Gap: Entire workflow missing.

### R054 — Valuation case pinned; purchase price stored separately
- Spec: V10 s6
- Code: `valuation model versions` on `dev`
- Evidence: Valuation versions exist.
- Gap: No deal term object compared to model output.

### R055 — Signing and closing require approval evidence
- Spec: V10 s7
- Code: `none in LedgerMind` on `dev`
- Evidence: External NexaDeals process is not this state machine.
- Gap: No closing checklist.

### R056 — Debt schedule identity and interest policy
- Spec: V11 s3
- Code: `debt_instruments; debt_schedule; shared projections debt` on `dev`
- Evidence: Schedules, revolver, PIK columns, tests for annuity safety.
- Gap: Covenant results are manually posted. Not calculated from governed state.

### R057 — Covenants from financial state
- Spec: V11 s3
- Code: `covenant_results POST` on `dev`
- Evidence: Tables exist.
- Gap: Compliance flag is client-supplied. July branch governs projected covenants but is unmerged.

### R058 — Cap table ledger, atomic transfer, immutable published table
- Spec: V11 s4
- Code: `capital-markets.routes.ts` on `dev`
- Evidence: CRUD for rounds, holders, option pools. Dilution helper.
- Gap: No published immutable cap table. No liquidation preference waterfall.

### R059 — Fundraising close updates ownership only when approved
- Spec: V11 s5
- Code: `capital-access.routes.ts` on `dev`
- Evidence: Some apply endpoints return a fake id and do not persist. Term sheet parsing is real.
- Gap: Scenario isolation until close is absent.

### R060 — LBO sources = uses, debt paydown, MOIC, IRR
- Spec: V11 s6; V7
- Code: `server/services/valuation/lbo; tests/lboEngine.test.ts` on `dev`
- Evidence: Server LBO with versioned models. Sources=uses tested.
- Gap: IRR assumes a single exit cash flow. No full waterfall.

### R061 — Waterfall preferences and participation
- Spec: V11 s2
- Code: `ExitStrategy.tsx client net proceeds` on `dev`
- Evidence: Client gross-proceeds minus debt minus fees.
- Gap: No preference stack.

### R062 — IFRS, US GAAP, local GAAP as policy over facts
- Spec: V12 s2-3
- Code: `companies.reportingStandard` on `dev`
- Evidence: Same COA ranges for both standards.
- Gap: No policy resolver or second reporting basis.

### R063 — Tax isolated from core facts
- Spec: V12 s2
- Code: `defaultTaxRate; tax_rates table` on `dev`
- Evidence: Projection tax rate and a tax rate CRUD.
- Gap: Not a jurisdiction rules engine.

### R064 — Functional, transaction, presentation currency
- Spec: V12 s2
- Code: `companies.primaryCurrency; transactions.currency` on `dev`
- Evidence: Fields exist.
- Gap: No translation policy.

### R065 — i18n: locale is not an identifier; Unicode; explicit currency
- Spec: V12 s7
- Code: `client/src/lib/currency.ts` on `dev`
- Evidence: Currency formatting.
- Gap: No translation catalog.

### R066 — Data residency and region placement
- Spec: V12 s2
- Code: `PROJECTION_COMPUTE_REGION comment` on `dev`
- Evidence: Logged stub only. allowedJurisdictions unused.
- Gap: No residency enforcement.

### R067 — SSO, MFA, RBAC
- Spec: V12 s6
- Code: `localAuth.ts; mfaService.ts; roles.ts` on `dev`
- Evidence: Session, TOTP, admin MFA required, team permissions. SAML returns 503 on dev.
- Gap: ABAC absent. SAML is on an unmerged branch.

### R068 — SOC2/SOX-oriented evidence: SoD, immutable audit
- Spec: V12 s5
- Code: `audit_logs hash chain` on `dev`
- Evidence: Hash chain under row lock.
- Gap: before/after null. Rows deletable on company delete. Dual control flags unused.

### R069 — DR RPO 15 min RTO 60 min exercised
- Spec: V12 s8; V5
- Code: `s3BackupService.ts; backup routes` on `dev`
- Evidence: pg_dump to S3 code exists.
- Gap: Restore exercise is mocked. Risk register P0-005.

### R070 — Observability with financial-impact alerts
- Spec: V12 s8; V5
- Code: `sentry.ts; financialAlertService.ts` on `dev`
- Evidence: Sentry and cash/runway alerts.
- Gap: No tenant SLO or trace of calculation run id.

### R071 — Onboarding state machine to FINANCIAL_STATE_READY
- Spec: V13 s3
- Code: `cfo onboard routes` on `dev`
- Evidence: Multi-step onboard UI.
- Gap: No case object, no certificate, no publish gate.

### R072 — Entity hierarchy, ownership, effective dates
- Spec: V13 s3.1
- Code: `companies.subsidiaries` on `dev`
- Evidence: JSON list of names.
- Gap: No entity table or effective dating.

### R073 — Opening balances balanced and approved
- Spec: V13 s3
- Code: `companies.startingBalance; openingBalanceCoverage.ts` on `dev`
- Evidence: Starting cash and projection opening month.
- Gap: No approved opening trial balance gate.

### R074 — 13-week roll-forward and scenario isolation
- Spec: V13 s4
- Code: `removed 2a2caeedb` on `dev`
- Evidence: Pricing string and blog text remain. Statutory indirect CF and monthly projection cash exist.
- Gap: Weekly engine, actualization, and minimum-cash policy absent.

### R075 — Liquidity alerts from headroom policy
- Spec: V13 s4.5
- Code: `financialAlertService.ts` on `dev`
- Evidence: Cash balance and runway alerts.
- Gap: Not 13-week headroom. AI cannot be shown to suppress them; policy engine is absent.

### R076 — Normalization ledger: proposed until approved, evidence, reversible
- Spec: V13 s5
- Code: `income_statement_normalization_adjustments` on `dev`
- Evidence: Adjustments can be stored.
- Gap: Save deletes and reinserts. New rows default approved. No evidence refs.

### R077 — QoE: revenue quality, EBITDA bridge, NWC, net debt, findings
- Spec: V13 s6
- Code: `boardPackGenerationService EBITDA waterfall` on `dev`
- Evidence: One-period revenue-to-EBITDA waterfall for a pack.
- Gap: Not a QoE case. No findings object.

### R078 — Diligence workstreams and evidence ACL
- Spec: V13 s7
- Code: `none` on `dev`
- Evidence: No workstream model.
- Gap: Missing.

### R079 — Transaction bridge EV to equity with NWC and net debt versions
- Spec: V13 s8
- Code: `modelingEvaluateService equity = EV - debt + cash` on `dev`
- Evidence: Simplified bridge.
- Gap: No peg, debt-like items, or versioned bridge object.

### R080 — V13 APIs for onboarding, cash, normalization, qoe, diligence, bridges
- Spec: V13 s9.2
- Code: `none at /v1` on `dev`
- Evidence: No matching routes.
- Gap: Missing.

### R081 — V13 golden tests ONB, CASH, NORM, QOE, DD, TXN, AI
- Spec: V13 s12.1
- Code: `none of those IDs` on `dev`
- Evidence: No tests with those invariants for V13 objects.
- Gap: Missing.

### R082 — Tenant isolation tests and company scope on mutations
- Spec: V3 security fixture
- Code: `tests/security/crossTenantAccess.security.test.ts; companyMiddleware.ts` on `dev`
- Evidence: Server company context and security tests, many mocked.
- Gap: No RLS. getTransactionById ignores companyId. Debt by userId.

### R083 — Encryption of secrets and upload controls
- Spec: V2 security body; V5
- Code: `accounting/encryption.ts; fileUpload.ts; virusScanner.ts` on `dev`
- Evidence: AES-GCM for bank tokens. Magic-byte upload checks. ClamAV required in prod compose.
- Gap: Scanning skipped in development. Risk register still open on prod scanning.

### R084 — Calculation benchmark harness 10k nodes
- Spec: V3 s11; V2 doc 09 body
- Code: `none` on `dev`
- Evidence: No benchmark harness in CI.
- Gap: NFR unmeasured.

### R085 — Two accounting bases without mutating canonical facts
- Spec: V12 exit criteria
- Code: `reportingStandard label` on `dev`
- Evidence: Single presentation path.
- Gap: Missing.

### R086 — AI cannot directly publish financial state
- Spec: V13-AI-001
- Code: `chat tools read-only` on `dev`
- Evidence: No publish tool. Tax suggestion can create a Tax Payable account. Categorize can change accounts before user post.
- Gap: Not a tested gate.
