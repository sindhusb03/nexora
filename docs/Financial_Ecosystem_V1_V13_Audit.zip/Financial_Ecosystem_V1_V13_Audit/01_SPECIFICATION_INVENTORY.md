# 01 — Specification Inventory

**Source:** `C:\Users\sindh\Download_Data\Financial_Ecosystem_V1_V13_Master.zip`  
**SHA-256 of each file:** `MASTER_MANIFEST.json` in the archive.  
**Extracted text:** `C:\Users\sindh\Download_Data\Financial_Ecosystem_V1_V13_Text\`  
**Created:** archive metadata dates the PDFs to 29 September 2026. C2PA credentials inside several V2 files name generator `gpt-5-6`.

The archive index (`MASTER_INDEX.txt`) lists V1 through V13 as a cumulative stack. Later versions add scope. They do not say earlier requirements are withdrawn, except where V4 explicitly marks items “later.”

## Document quality

| Version | File | Pages | Extracted substance | Quality |
| --- | --- | ---: | --- | --- |
| V1 | `V1_Baseline/Financial_Ecosystem_User_Flows.pdf` | 4 | Full user-flow text | Usable baseline |
| V2 | 14 PDFs in `Financial_Ecosystem_V2_Engineering_Specification_Pack/` | 1 each | One-page outlines. Bodies do not match filenames. | Defective |
| V3 | `Financial_Ecosystem_V3_Executable_Financial_Kernel.pdf` | 4 | Kernel contract, with ReportLab object dumps inside tables | Usable, tables corrupted |
| V4 | `Financial_Ecosystem_V4_MVP_Product_and_Build_Specification.pdf` | 6 | MVP scope, journey, APIs, epics | Usable, tables corrupted |
| V5 | `Financial_Ecosystem_V5_Production_System_Architecture_and_Implementation_Blueprint.pdf` | 9 | Services, repo layout, stores, security, CI, DR | Usable, tables corrupted |
| V6–V12 | Eight PDFs, about 4–7 KB, 1–2 pages | 2 | Construction outlines that match their titles | Usable as outlines, not build-ready detail |
| V13 | V13 engineering specification | 12 | Onboarding, 13-week, normalization, QoE, diligence, bridges, APIs, golden IDs | Best-formed document in the pack |

V6–V12 and V13 restate the same architectural rules as V3: deterministic numbers, immutable publication, tenant isolation, AI does not own financial truth, lineage on material outputs.

### V2 filename / body mismatch

Content streams were decoded directly (PDF text operators), not inferred from titles.

| Filename says | Body actually describes |
| --- | --- |
| 00 Pack index | Thesis, P0/P1 gates, required repositories. Aligned. |
| 01 Ontology | Placeholder sentence only. Ontology body missing. |
| 02 Accounting engine | Canonical state chain and contract rules (ontology-level). |
| 03 Consolidation | Balanced journals, period gates, reversals, replay tests (accounting). |
| 04 Multi-currency | Consolidation pipeline and IC/NCI tests. |
| 05 Calculation language | FX semantics and “no silent 1.0 fallback.” |
| 06 Golden tests | Typed model DAG and incremental invalidation. |
| 07 OpenAPI | Golden-suite invariants. |
| 08 NFRs | API envelope and event names. |
| 09 Excel | SLO text: 99.95% availability, RPO 15 min, RTO 60 min, 10k-node benchmark. |
| 10 AI safety | Excel-first client and untrusted macros. |
| 11 Security | AI gateway and “LLM never writes directly to the database.” |
| 12 M&A | Security and SOC 2 / ISO mapping. |
| 13 Implementation plan | Deal state machine. The implementation-plan body is absent. |

This audit treats V2 requirements by **subject**, and uses V3–V13 where they specify the same subject with more detail. It does not invent the missing V2 page bodies.

## Cumulative model

```text
V1  User roles, lifecycle, AI governance sketch, M&A sketch, board, permissions
 ↓  still required
V2  Engineering thesis and P0/P1 gates (outlines only; bodies misfiled)
 ↓  still required; V4 narrows the first ship
V3  Executable kernel: journals, facts, consolidation, FX, DAG, lineage, publication
 ↓  still required
V4  MVP loop. Explicitly later: full tax/GAAP automation, complex instruments,
    trading workflows, full M&A marketplace, full LBO/M&A suite, advanced data room,
    mobile-first, autonomous agent
 ↓  later items return as V10–V13, not as MVP
V5  Production assembly: modular monolith allowed, service ownership boundaries,
    Postgres + object storage + search/vector + queue, IaC, environments
 ↓
V6  Construction contracts: tables, /v1 routes, error codes, fixtures, sprints
 ↓
V7  Reference kernel loop and test pyramid, including DCF identities
 ↓
V8  Web surfaces + Excel add-in as a controlled client
 ↓
V9  AI gateway, tools, retrieval, evaluation. AI must not mutate storage directly
 ↓
V10 Deal lifecycle, data room ACL, diligence, valuation cases kept separate from price
 ↓
V11 Debt, covenants, cap table, fundraising, LBO, waterfall
 ↓
V12 Policy layer for IFRS / US GAAP / local GAAP, residency, enterprise controls
 ↓
V13 Onboarding certificate, 13-week cash, normalization ledger, QoE, diligence
    workstreams, transaction bridge. Depends on V3, V5, V8, V9, V10, V11, V12
```

### Introduced, modified, or deferred

| Requirement | Introduced | Later treatment |
| --- | --- | --- |
| Business Owner, CFO, FA, IB, Board, Platform Admin | V1 | Restated V12/V13. Not deprecated. |
| AI proposes, humans approve, calculation engine owns numbers | V1 §15 | Repeated V2, V3, V9, V13. Non-negotiable. |
| Deal flow through closing | V1 §8, V2 body of doc 13 | V4 says full M&A is later. V10 makes it a product. Cumulative, not cancelled. |
| Canonical ontology and immutable published versions | V2/V3 | Restated V6, V7, V12. Not deprecated. |
| Consolidation and FX | V2/V3 | V4 includes “multi-entity basics” and “multi-currency basics” in MVP. Full NCI/translation remains a kernel requirement. |
| Excel add-in | V2 P1, V4 P1, V8 | Not deferred past MVP foundations. |
| Full LBO suite | V4 “explicitly later” | Returns as V7 fixture and V11. Required for V11, not for V4 MVP. |
| Data room | V4 “later” | Required in V10 and V13 diligence. |
| 13-week cash, QoE, normalization ledger, onboarding certificate | V13 | New. Depends on kernel. Does not replace statutory cash flow. |
| Tax/local GAAP automation | V4 later | V12 says policy produces interpretations, not mutated facts. Phase 1 is one reporting jurisdiction. |

### Contradictions inside the spec pack

1. **V2 documents are not reliable as standalone specs.** Titles and bodies disagree. V3–V13 are the operative text for those topics.
2. **V4 vs V10/V11.** V4 defers the M&A marketplace and the full LBO suite. V10 and V11 require them later. That is a phase cut, not a cancellation, because V4 says “explicitly later.”
3. **V5 allows a modular monolith** while also drawing separate services. The ownership boundaries are mandatory. Separate deployables are not mandatory for the first kernel.
4. **V3 tables are machine-dumped** (`Paragraph(...)`, `Table(...)`). Cell text was recovered from those dumps. Where a cell could not be recovered, the requirement is marked from the surrounding prose only.
5. **Numeric NFRs disagree in precision only.** V2/V5/V8/V13 all cite p95 reads under 400 ms, 10k-node model under 5 s cold / 1 s incremental, RPO 15 min, RTO 60 min, 99.95% availability. No document supersedes another on these numbers.
6. **V6 error `FX_RATE_MISSING` and V3 “missing rates block calculation”** agree. No spec permits a silent rate of 1.

### Implementation priority implied by the documents

P0 gates (V2 index, V3 definition of done, V4 in-scope): ontology, ledger invariants, versioned state, three statements, scenarios, valuation, board pack, golden tests, tenant isolation.

P1: Excel foundations, grounded AI, basic multi-entity and multi-currency.

Later waves (V10–V13): transactions, capital structure, jurisdiction packs, 13-week cash, QoE, diligence.

The code should be scored against that order. A strong LBO screen does not satisfy a missing ledger invariant.

## Requirements carried into the matrix

The traceability matrix scores **86 requirements** taken from text that was actually extracted. It does not score blank V2 pages as if they contained a full data model. Each row cites the version that states the requirement in readable form.

Spec paths used as references:

- V1: `V1_Baseline/Financial_Ecosystem_User_Flows.pdf`
- V3: `Financial_Ecosystem_V3_V4/Financial_Ecosystem_V3_Executable_Financial_Kernel.pdf`
- V4: `Financial_Ecosystem_V3_V4/Financial_Ecosystem_V4_MVP_Product_and_Build_Specification.pdf`
- V5: `Financial_Ecosystem_V5_Production_System_Architecture/...pdf`
- V6–V12: `Financial_Ecosystem_V6_V12_Detailed_Engineering_Pack/V*.pdf`
- V13: `Financial_Ecosystem_V13_..._Engineering_Specification.pdf`
