# 14 — Security and Compliance Audit

UI hiding a nav item is not authorization. This section uses server code.

## Authentication

`server/localAuth.ts` uses `express-session` with `connect-pg-simple`, httpOnly cookies, `sameSite=lax`, and refuses insecure cookies in production. Passwords are bcrypt. MFA is TOTP (`mfaService.ts`) and required for admin and superadmin (`requireRole.ts`). CSRF, rate limits, helmet, and session-version revocation exist.

SAML routes return 503 `SSO_UNAVAILABLE` on `dev`. The comment in `localAuth.ts` says verification, tenant binding, and replay protection are not implemented there. `feat/saml-signature-verification` (`fe051ea5f`) adds them and is not merged. SCIM is implemented (`scim.routes.ts`) and is not in the V1–V13 PDFs.

`fix/session-revocation-all-shapes` revokes additional session shapes on password reset and GDPR erasure. That fix is not on `dev`.

## Authorization

RBAC, not ABAC. `shared/roles.ts`: system roles user/admin/superadmin; team roles owner/admin/reviewer/auditor/viewer with a fixed permission map. `authorizationService.ts` is the company decision. `attachCompanyContext` reads `x-company-id`, then the session company, then the first accessible company, and requires a manage permission on non-GET requests.

There is no Postgres row-level security (`CREATE POLICY` not in migrations).

V1 personas (CFO, analyst, banker, board) are not roles. Board readers use a magic link (`board-portal.routes.ts`), not an account role.

## Object access

Several storage getters load by id without `companyId`: documents, uploaded statements, term sheets, fixed assets, board packs, saved projections, reports. Routes that were sampled re-check the company after the load (`board-packs`, projections, custom reports, operations loaders). `getTransactionById` accepts `companyId` and ignores it. `POST /api/cfo/transactions/:id/correction` in `remaining-legacy.routes.ts` uses a narrower owner check. This is safe only while every caller re-checks. A new route that forgets the check is an IDOR.

Debt-by-user and `getExchangeRates` without company are the confirmed scope bugs, not theoretical ones.

## Audit

`audit_logs` is hash-chained per company (`previousHash`, `currentHash`) under a row lock. Middleware logs POST/PUT/PATCH/DELETE. `correlationId` comes from `x-correlation-id` or is generated. `beforeState` and `afterState` are always null. A failed audit write does not fail the request. Reads are not logged. Company id on the log can come from the session rather than `req.companyId`. Company delete and `dataRetentionService.ts` remove audit rows. Nothing in the database prevents `UPDATE` or `DELETE` on `audit_logs`.

Financial mutations do not log a financial-state version, calculation run, or engine version, except the separate projection and modeling audit tables.

## Injection and files

Drizzle is the query path. This audit did not find a general raw-SQL tool exposed to the model. Upload checks magic bytes and size (`fileUpload.ts`). Bank tokens use AES-256-GCM (`accounting/encryption.ts`). ClamAV is required in `docker-compose.prod.yml` and skipped in development.

The critical file issue is not the upload middleware. It is Git tracking of `uploads/.../data-room/` customer PDFs and CSVs.

## Compliance (V12)

| Control | Status |
| --- | --- |
| SSO | Fail-closed on dev; implemented on an unmerged branch |
| MFA | Implemented for privileged roles |
| RBAC | Implemented |
| ABAC | Absent |
| SoD / maker-checker | Flags stored, not enforced |
| Immutable audit | Hash chain in application code; rows are deletable |
| Second GAAP basis | Absent |
| Data residency | `PROJECTION_COMPUTE_REGION` is a log stub |
| Export controls | Not a policy engine |
| AI governance inventory | Absent |

SOC 2 or ISO certification is not claimed by this audit. The spec itself says architecture is not certification.

## AI security

See `10_AI_AUDIT.md`. The model cannot run arbitrary SQL through the CFO tool map. It can influence which accounts a transaction posts to. Prompt injection is untested. There is no cross-tenant retrieval suite because there is no retriever.
