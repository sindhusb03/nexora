# 03 — Branch Analysis

Comparisons use `git log` and `git diff` (triple-dot against `main` and against `dev`). No branch was checked out. Counts below are from that comparison, not from branch age.

`main` (`e606c4bae`) is a squash. History-based “ahead” counts therefore overstate product drift. File-level drift `main..dev` is the SDLC contract and small fixes. None of the feature branches below is an ancestor of `dev`.

## Capability matrix

| Capability | main `e606c4bae` | dev `426751887` | guided CFO `339d41021` | readiness `60d42025e` | financial audit `4d526b4a7` | SAML `fe051ea5f` | session revoke `05c60b0bf` | Best implementation | Merge status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Three-statement projections | Yes | Yes | Yes, plus workspace UX | Yes | Yes, plus fiscal/capex/tax authority not in dev | Same as main | Same as main | July branch for authority; dev for current engine integration | July work unmerged; must be ported |
| AI projection citations | Partial copilot | Partial copilot | CFO workspace evidence service | Same base as guided, without workspace tip | `projectionCitationPolicy.ts` and claim checks | No | No | July branch | Unmerged |
| Ledger immutability | Mutable transactions | Mutable transactions | `ledger*.ts` posting/close policy, journal draft list, migrations `0014_five_country_ledger`, `0015_pilot_billing_scope` | Same ledger groundwork | Not this branch’s focus | No | No | Guided/readiness pair, still a checkpoint | Unmerged |
| SAML login | Endpoints return 503 | Endpoints return 503 | No | No | No | Signature verify, replay table, tests | No | SAML branch | Unmerged; new dependency; migration number clash |
| Session revocation on erasure | Partial | Partial | No | No | No | No | All session shapes, `auth_version` bump, Postgres test | Session branch | Unmerged, small |
| Reconciliation atomicity | Yes, expanded | Yes | Yes | Yes | Older | No | No | dev | `origin/review/reconciliation-atomicity-20260911` obsolete |
| Dashboard story panels | No | No | Included in workspace tip | No | No | No | No | `feat/cfo-dashboard-story-panels` for the small grid; guided branch for the larger UX | Unmerged |
| Agent config guard | SDLC docs only | SDLC docs | No | No | No | No | No | `feat/agent-config-guard` | Unmerged, non-financial |
| Customer files in Git | 14 tracked | 14 tracked | Still tracked | Untracks `uploads/` | Old tree | No | No | Readiness branch for the deletion only | Not merged |

## Branch notes

### `feat/guided-cfo-workspace` (`339d41021`, 28 Sep 2026)

Six commits ahead of `dev`. About 240 files differ from `dev`. Adds ledger posting and close policy, five-country import groundwork, Excel **import interpretation** (not an add-in), Plaid webhook verification, `shared/fiscalCalendar.ts`, journal draft list, and guided CFO workspace chat. Commit messages say checkpoint. Docs say draft limits. Not production-ready. Overlaps the July branch’s fiscal-period work and the readiness branch’s ledger commits.

### `fix/production-readiness-20260927` (`60d42025e`)

Sibling of the guided branch: same five ledger/import commits, plus a commit that records a skill and untracks local artifacts. It does not contain the guided workspace tip. It is the only branch that removes the 14 tracked `uploads/` files. A stash from 29 Sep 2026 sits on this branch and was not audited as code.

### `audit/global-financial-engine-2026-07` (`4d526b4a7`, 17 Jul 2026)

About 63 commits ahead of the old main line and 74 behind `dev`. Unique work includes DCF timing and stub periods, fiscal capex and depreciation continuity, forecast tax policy, TTM ratio alignment, covenant and coverage governance, saved-projection and board-pack projection authority, and AI citation/claim enforcement. Those files are not on `dev`. A merge would also delete a very large amount of later `dev` code and collide with migrations `0002+`. **Port with finance review and golden tests. Do not merge.**

### `feat/saml-signature-verification` (`fe051ea5f`)

Based on `main`, two commits, not in `dev`. Implements organization SAML signature verification and `0014_saml_assertion_replays`. `dev` still fail-closes SSO with `SSO_UNAVAILABLE` because verification was not implemented there (`server/localAuth.ts`). Adds a production dependency (lockfile growth). Migration `0014` collides with `0014_five_country_ledger` on the guided branch. Checkpoint label. Merge only after dependency approval and renumbering.

### `fix/session-revocation-all-shapes` (`05c60b0bf`)

Two commits on `main`, six files: session helper, GDPR erasure, password reset, spec, unit test, Postgres test. Not in `dev`. Clearest small merge candidate.

### Small and non-financial

- `feat/agent-config-guard` (`436dd0873`): CI guard for agent instruction paths. Three commits ahead of `dev`.
- `feat/cfo-dashboard-story-panels` (`b36bc22ec`): 2×4 KPI story grid. One commit ahead of `dev`.

### Obsolete against current `dev`

| Branch | Why |
| --- | --- |
| `fix/codex-readiness-auth` | Enterprise/auth files exist on `dev` in newer form. Unique leftover is a Deal Physics page `dev` redirects away from. |
| `fix/cursor-readiness-build` | Static serving split already on `dev`. |
| `fix/payment-event-safety` | Billing event durability already on `dev`, further along. |
| `chore/agent-sdlc-adapters` | Byte-identical SDLC files landed via PR #23. |
| `origin/review/reconciliation-atomicity-20260911` | Match/unmatch serialization is on `dev`. |
| `origin/cleanup/production-focused-dead-code` | July dead-code deletion. Re-running it on today’s tree would be a new change, not a merge. |

## Concepts searched in history

| Concept | Result |
| --- | --- |
| Consolidation / NCI | No implementation commit. `consolidatedReporting` is an unused boolean. “Intercompany” appears as statement labels. |
| 13-week cash | Implemented, then removed in October 2025. Pricing text remains. |
| Quality of earnings | M&A intelligence QoE removed January 2026. Income-statement normalization adjustments remain. |
| Cap table | Added December 2025 and still present in `capital-markets.routes.ts`. |
| Data room | Built late 2025, removed February–March 2026. Files remain in Git. |
| Excel add-in | No Office.js commit on any branch. |
| RAG / embeddings | No vector store commit. Grounding and citation work is not retrieval. |

## Engineering recommendation

Order, based on risk and conflict, not age:

1. Plan removal of tracked `uploads/` (the readiness branch shows the deletion; history purge is a separate human decision).
2. Merge session revocation after review.
3. Merge SAML only with an approved dependency and a renumbered migration.
4. Choose one of guided-workspace vs readiness for the ledger/import checkpoint, then review it as financial work.
5. Port July financial-authority commits onto current `shared/projections` and valuation code.
6. Leave the six obsolete branches unmerged.
