# 23 — Target Architecture

The target below is the V1–V13 model. It is not a claim that the repository already has it. Distance is in `18_ARCHITECTURE_DELTA.md` and `25_FINAL_READINESS_REPORT.md`.

```mermaid
flowchart TB
  subgraph intel [AI intelligence]
    RAG[RAG and agents]
    UX[Web and Excel add-in]
  end
  subgraph fin [Financial intelligence]
    FC[Forecast]
    CASH[13-week cash]
    NORM[Normalization]
    QOE[QoE]
    VAL[Valuation]
    CAP[Debt equity LBO]
    MA[M and A diligence]
    BRD[Board reporting]
  end
  subgraph ker [Financial kernel]
    ACC[Accounting]
    ST[Financial state]
    CON[Consolidation]
    FX[FX]
    GR[Calculation graph]
    LIN[Lineage and versions]
  end
  subgraph data [Data foundation]
    SRC[Accounting banks payroll ERP]
    DOC[Documents and data rooms]
    XL[Excel]
  end
  UX --> RAG
  RAG -->|governed tools and evidence| fin
  fin -->|deterministic calculations| ker
  data --> ker
```

## Rules that define “done”

1. Published financial state is immutable and versioned.
2. AI may propose and explain. It may not publish or silently reclassify.
3. Every material number resolves to source, mapping, adjustment set, assumption set, formula or engine version, scenario, FX policy, and approval.
4. Excel and the browser send inputs and render outputs.
5. Consolidation and FX are either implemented or not advertised.
6. Tenant and deal ACLs are enforced in the query, not only in the router after a global fetch.

## What to reuse

Keep `shared/projections`, DCF, LBO, board-pack freeze, session RBAC, debt schedules, cap table tables, bank-match locks, and the audit hash chain. Wrap them with versioned state and stricter writes. A rewrite of the forecast engine into a DAG is P2, after authority is fixed. V5 allows one deployable.

## Service boundaries to enforce inside the monolith

| Module | May | May not |
| --- | --- | --- |
| `server/accounting` | Post reversals, lock periods | Forecast formulas |
| `shared/projections` | Pure calculate | Read or write the database |
| Ingestion | Store immutable source payloads | Overwrite a published snapshot |
| AI | Call read tools and draft text | Insert transactions or approve adjustments |
| Board pack | Render a pinned snapshot | Recompute unpublished client grids |
| Valuation | Read a pinned forecast version | Treat book equity as EV |

## Target data flow for the V4 loop

```text
source file (immutable)
  → mapping set version
  → reconciled facts version
  → published financial state
  → server calculation run (engine build + input hash)
  → scenario overlay (base unchanged)
  → valuation run (pinned state + rate set)
  → board pack (state hash)
```

## Target V13 flow, after that loop is true

```text
published state
  → normalization adjustment set (proposed until approved)
  → QoE schedules and findings
  → 13-week cash (separate from statutory CF)
  → transaction bridge (EV, net debt version, NWC peg)
  → diligence evidence ACL
```

## Non-targets

Separate microservices, a vector database, and multi-region residency are V5/V12 scale items. They are not the next architecture change. An autonomous agent is explicitly out of the V4 MVP.
