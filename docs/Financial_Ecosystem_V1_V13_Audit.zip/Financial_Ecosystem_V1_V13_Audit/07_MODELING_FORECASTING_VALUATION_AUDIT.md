# 07 — Modeling, Forecasting, and Valuation Audit

Baseline: `dev` at `426751887`. The July audit branch has stricter projection and DCF controls that are not in this tree.

## V4 loop

Specified path:

```text
Accounting data → governed financial state → 3-statement model → forecast
→ scenarios → valuation → board output
```

| Step | What runs | Gap |
| --- | --- | --- |
| Accounting data | CSV/Excel ingestion and a separate GL | Two sources, no single published state |
| Governed state | Review package `draft → published`; statement jsonb replaced on republish | Not a versioned state hash |
| 3-statement model | `shared/projections` growth, scenario, KPI | Imperative, floats, server optional |
| Forecast | Same engines, monthly | Not a DAG |
| Scenarios | `conservative`, `base`, `aggressive` as percent shocks | Base is the only case fully tie-out checked |
| Valuation | DCF, market multiples from an external comps query, LBO | Simplified equity bridge |
| Board output | PDF board pack with publish freeze | Not generated from a kernel state id |

## Forecasting

Server path: `server/routes/modules/projections.routes.ts` `/calculate` and `/calculate/batch` call `projectionCalculateService.ts`, which loads actuals, runs the shared engine, verifies three-statement integration, and writes fingerprints to `projection_calculate_audit`. A broken tie-out returns HTTP 422.

Client path: `GrowthBasedProjections.tsx`, `ScenarioBasedProjections.tsx`, `KpiDrivenProjections.tsx`, and `ProjectionAnalytics.tsx` call the same shared functions when server authority is off or the server call fails. Authority resolves from `companies.projection_server_authority`, then an environment default that is off outside production, then `?serverCalc=0` (`useProjectionServerAuthority.ts`).

Save path: unless `PROJECTION_STRICT_SAVE=true`, `/auto-save` and `/save` store the client grid. That violates the repository rule that the client sends inputs only.

Debt loaded for the forecast uses `storage.getDebtInstruments(userId)` (`projectionCalculateService.ts`). The query filters on user, not company. A user with two companies can pull both companies’ debt into one forecast.

`ENGINE_VERSION` is `1.2.0`. The July branch (`4d526b4a7`) changes fiscal period alignment, capex policy, tax policy, ratio lookback, and saved-projection authority. Those files are absent on `dev`. Current forecast behavior should be treated as the `dev` engine, not as the July fixes.

Scenarios do not write back to uploaded actuals. That part of isolation holds. There is no approval or lock on a scenario. Auto-save upserts a row named like an auto-save.

## Valuation

`shared/valuation/dcfCalculations.ts`: yearly and monthly FCFF, mid-period discounting, Gordon growth terminal value, WACC from CAPM. Server evaluation is `modelingEvaluateService.ts`. UI: `DCFModel.tsx`, `WACCCalculator.tsx`, `ValuationSuite.tsx`.

Equity value in the evaluate service is enterprise value minus debt plus cash. V13’s bridge also requires a working-capital peg, debt-like items, and other claims. Those are absent.

The weighted valuation path averages methods and can treat book equity as an enterprise-value method. That is a methodology problem, not a missing screen.

Market multiples: `valuation.routes.ts` reads external `pc_ratios_live` and `precedent_transaction` for EV/Revenue, EV/EBITDA, and P/E. P/B is hard-coded to 0. Transaction P/E is 0. Those zeros are shipped behavior, not a placeholder comment.

Profiles are versioned (`valuation_profiles` and related tables). LBO models have `valuation_model_versions` (migration `0013`). DCF timing and stub-period fixes live only on the July branch.

## Board and lineage UI

`boardPackLifecycle.ts`: version conflict checks, published packs return 409 on edit, publish requires readiness and a currency snapshot, portal uses a magic link. `pptxFileUrl` is never populated.

Lineage UI is `client/src/components/financial/trace/`: static formulas keyed by line label. It does not open the calculation run.

## Tests that actually constrain this area

- `tests/threeStatementIntegrity.regression.test.ts` — balance sheet identity, cash roll, retained earnings roll-forward.
- `tests/cashFlowReportIntegrity.regression.test.ts`
- `tests/dcfFormulaIntegrity` (named in the suite)
- `tests/contracts/projection-calculate.contract.test.ts`
- `tests/golden/financial-baseline.golden.test.ts` — one inline snapshot of ratios and helpers, not a full model.

They do not fix the client-save bypass. They prove the pure functions when those functions are what runs.

## Verdict

Modeling and valuation are the strongest financial product surface. They are IMPLEMENTED_WITH_GAPS against V4 and IMPLEMENTED_DIFFERENTLY against the V3 graph. They are not production-ready as a governed forecast until strict save, company-scoped debt, and the July authority fixes are decided and tested.
