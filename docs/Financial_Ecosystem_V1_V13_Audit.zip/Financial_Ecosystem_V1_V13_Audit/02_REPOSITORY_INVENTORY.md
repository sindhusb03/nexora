# 02 — Repository Inventory

**Repository:** `C:\xampp\htdocs\My Projects\LedgerMind`  
**Audit HEAD:** `426751887` on `dev` (tracks `origin/dev`)  
**`main` / `origin/main`:** `e606c4bae` (27 September 2026)  
**Tags:** none (`git tag` empty)  
**Uncommitted work at audit start (excluded from “shipped” claims):** `client/src/App.tsx`, `client/src/admin/moduleRegistry.ts`, `client/src/lib/echartsCore.ts`, `client/src/lib/utils.ts`, `server/vite.ts`

## What this repository is

LedgerMind (older name NexaFI) is a React  + Vite client, an Express API, PostgreSQL via Drizzle, Jest, and Playwright. It is not Next.js. Layout:

| Path | Role |
| --- | --- |
| `client/src` | UI, TanStack Query, Wouter routes |
| `server` | Express routes, services, accounting module, auth |
| `shared` | Drizzle schema, projection engines, valuation math, roles |
| `tests` | Unit, regression, a thin golden file, contracts, security, some Postgres integration |
| `e2e` | Playwright |
| `migrations` | Drizzle SQL, baseline `0000` through `0013_lbo_model_versions.sql` on `dev` |
| `docs` | Finance docs, specs, launch risk register, agent SDLC |
| `.github/workflows` | CI, release, deploy-by-SSH, security scan |

There is no `apps/web`, `apps/excel-addin`, `packages/calculation-engine`, `infra/terraform`, or `schemas/openapi` tree of the kind V5 specifies.

## Branches observed

Local:

- `dev` (current), `main`
- `audit/global-financial-engine-2026-07`
- `chore/agent-sdlc-adapters`
- `feat/agent-config-guard`
- `feat/cfo-dashboard-story-panels`
- `feat/guided-cfo-workspace`
- `feat/saml-signature-verification`
- `fix/codex-readiness-auth`
- `fix/cursor-readiness-build`
- `fix/payment-event-safety`
- `fix/production-readiness-20260927`
- `fix/session-revocation-all-shapes`

Remotes:

- `origin/main`, `origin/dev`
- `origin/cleanup/production-focused-dead-code`
- `origin/fix/production-readiness-20260927`
- `origin/review/reconciliation-atomicity-20260911`

No branch is named for a financial kernel, Excel add-in, or RAG. The July branch `audit/global-financial-engine-2026-07` is the financial-kernel-adjacent history. M&A in-repo is a NexaDeals handoff plus removed data-room history.

`main` is a squash of an earlier `dev` (`e606c4bae` message `Dev (#22)`). File drift from `main` to `dev` is small: agent SDLC contract and related CI/docs, plus minor dashboard, upload, and test fixes. Product behavior audited on `dev` is the product behavior on `main` unless a report says a commit is only on `dev`.

## History shape (selected)

Recent product commits already on `dev`/`main` include LBO checkpoint and production hardening (`444ac79e4`), report publication protection (`cb27f8a7d`), Capital Access / NexaDeals handoff (`9a3d1b2af`, `4b959655b`), CFO copilot (`4c82877cb`), debt current-liability handling (`096ffb73e`, `8c816d74f`), and projection engine consolidation under `shared/` (`5311e6995`).

Older history, confirmed by `git log --all --grep`:

| Commit | Date context | What happened |
| --- | --- | --- |
| `69b8f6b3d` | 2025-10-08 | 13-week cash tab shown when transactions are recent |
| `2a2caeedb` | 2025-10-11 | 13-week forecast replaced by a cash-balance waterfall |
| `55a422f95` | 2026-01-14 | M&A intelligence features removed |
| `7d8ac9329`, `d6a8c5dbc` | 2026-02/03 | Data room module removed |
| `4d526b4a7` | 2026-07-17 | Tip of the global financial-engine audit branch; not merged |

Stashes exist (`refs/stash` on `fix/production-readiness-20260927`, and an older audit-branch stash in the reflog). They were not treated as implementation.

## Schema and route surface (dev)

Tenant key is `companyId` on `companies`. `organizations` sit above companies. `gray_label_tenants` is branding, not the financial tenant.

Financial tables that exist include `accounts`, `transactions`, `uploaded_financial_statements`, `cfo_line_item_mappings`, `fiscal_period_status`, `saved_projections`, `valuation_models` / `valuation_model_versions`, `debt_instruments`, `debt_schedule`, `covenant_tracking`, `covenant_results`, `board_packs`, `review_packages`, `audit_logs`, `projection_calculate_audit`, `modeling_evaluate_audit`, `income_statement_normalization_adjustments`, `exchange_rates`, `currencies`.

Tables named by V3/V6/V13 that were not found: `journal_entry` as a header, `journal_line`, `financial_fact` as a versioned fact store, `consolidation_group`, `fx_rate_set`, `model_node`, `calculation_run` as a first-class graph run, `onboarding_case`, `cash_forecast`, `cash_week`, `qoe_case`, `diligence_request`, `transaction_bridge`.

Route registration is `server/routes.ts` → `server/routes/modules/index.ts` (about 50 launch-gated routers) plus `server/accounting/routes.ts` and `server/routes/remaining-legacy.routes.ts`. There is no `/v1/journals` or `/v1/financial-states`. Swagger at `/api/docs` is a hand-written shell.

## Tests and delivery

`tests/` has on the order of 280 unit/regression files, 1 golden file, 5 contract tests, 5 security tests, and Postgres integration files that often skip unless a dedicated database URL is set. `e2e/` holds Playwright specs including a canary Excel path (file import/export, not Office.js).

Delivery: multi-stage `Dockerfile`, `docker-compose.yml`, `docker-compose.prod.yml` (app + ClamAV), PM2 `ecosystem.config.cjs`, GitHub Actions with a Postgres 15 service, SSH deploy to EC2. No Terraform, Kubernetes, Helm, Prometheus, or vector database.

## Tracked customer files

`git ls-files uploads` returns 14 paths, all under `uploads/a5628d05-1875-46d0-b976-ea8da0fc7f73/data-room/`, including bank-statement PDFs, balance sheets, income statements, and HR employee/department CSVs. They are on `dev` and `main`. `fix/production-readiness-20260927` is the branch that stops tracking them. Contents were not opened for this audit.
