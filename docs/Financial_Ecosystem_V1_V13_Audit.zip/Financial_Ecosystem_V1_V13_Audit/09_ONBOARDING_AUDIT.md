# 09 — Onboarding Audit

V13 section 3 defines onboarding as a state machine that ends in a published, reconciled financial state and a readiness certificate. V1 section 2 is the user-flow version of the same idea.

## Specified states

```text
DRAFT → COMPANY_CONFIGURED → ENTITIES_CONFIGURED → SOURCES_CONNECTED
→ COA_MAPPED → HISTORICAL_DATA_LOADED → OPENING_BALANCES_VALIDATED
→ RECONCILED → FINANCIAL_STATE_READY → PUBLISHED
```

Failure path: `NEEDS_REVIEW → REMEDIATION`.

## What exists on `dev`

| Gate | Evidence | Status |
| --- | --- | --- |
| Company setup | `cfo-companies.routes.ts` `/companies/onboard`, `simplified-onboard`, `onboard-step`. UI: `GettingStartedPage.tsx`, `SimplifiedOnboarding.tsx` | PARTIAL |
| Legal name, currency, fiscal year | Company columns including `primaryCurrency` | PARTIAL |
| Accounting basis | `reportingStandard` stored; both standards share COA ranges in `accountingSettingsService.ts` | Label only |
| Entity hierarchy | `subsidiaries` jsonb | NOT_IMPLEMENTED |
| Source connection | Excel/CSV via `excelParser.ts` and ingestion. Google Sheets import. QuickBooks/Xero marked beta in `shared/launchCapabilities.ts` and not enabled for workspace types | PARTIAL |
| COA mapping | `cfo_line_item_mappings`; integration `account_mappings`; accounting onboard creates a default 81-account chart | PARTIAL |
| Historical import | Upload pipeline and `ingest_facts` hashes | PARTIAL |
| Opening balances | `companies.startingBalance`; projection `openingBalanceCoverage.ts`; trial balance route | PARTIAL |
| Users and RBAC | Team invites, `user_company_memberships`, `authorizationService.ts` | IMPLEMENTED_DIFFERENTLY |
| Reporting configuration | Statement and board-pack setup | PARTIAL |
| Readiness certificate | None. Nearest control is board-pack export readiness | NOT_IMPLEMENTED |
| 100% mapped or quarantined before publish | Not enforced | NOT_IMPLEMENTED |
| Debits = credits on every imported journal batch | Upload lane is statement totals, not journals | NOT_IMPLEMENTED |

There is no `onboarding_case` row, no case version, and no `/v1/onboarding/cases/{id}/publish`.

## V1 role experience

The owner is not forced through a full accounting UI. Getting Started and the CFO dashboard match that intent in part. The V1 promise that AI identifies the chart, debt, and missing data, and the owner only approves, is not the onboard implementation. Categorization suggestions exist later, on transactions, not as an onboarding approval certificate.

## Workspace types

`shared/launchCapabilities.ts` lists workspace types (`business`, `cfo_advisor`, `cpa`, `pe_vc`, `professional`). They are not stored per user and are not enforced by server middleware. Navigation uses `servicePreference`. V1’s Development Company versus customer split is only partly reflected: superadmin and impersonation exist; a separate platform-admin role with no financial default is not a distinct principal.

## Verdict

Onboarding is a setup wizard plus import, status PARTIAL, completeness about 20–45% depending on the gate (see R003, R021, R044, R071–R073). It does not prove a tenant can produce a reconciled financial state before modeling. V13 says that proof is the point of onboarding.
