# 05 — Financial Kernel Audit

**Question:** does `dev` at `426751887` implement the V3/V7 deterministic financial kernel?

**Answer:** no. It implements a CFO forecasting application and a basic double-entry ledger. Those pieces are real. They are not a canonical financial state, a journal aggregate, a calculation graph, or a publication machine.

`graphify explain "journal posting"` returned no node. The useful code is still there under other names.

## What the kernel was required to own

From V3 sections 1–13 and V7 sections 1–9:

Ledger, periods, entities, consolidation, currencies, facts, adjustments, scenarios, model graph, formulas, calculations, lineage, approvals, immutable versions, reconciliation, audit events.

UI, documents, email, and AI conversation are outside the kernel and must consume its contracts.

## What the code owns instead

| Kernel idea | Code reality | Status |
| --- | --- | --- |
| One financial state | Two lanes: `uploaded_financial_statements` and `transactions` | NOT a single state |
| JournalEntry (debits = credits, posted immutable) | One `transactions` row with `debitAccountId`, `creditAccountId`, `amount` | IMPLEMENTED_DIFFERENTLY |
| FinancialFact version | `parsedData` jsonb, replaced in place (`ingestionService.ts`) | NOT_IMPLEMENTED |
| ModelVersion immutable after publication | `saved_projections` with fingerprints; client can write the grid | PARTIAL |
| CalculationRun keyed by input hash and engine | `projection_calculate_audit` and `modeling_evaluate_audit` | PARTIAL |
| Scenario does not mutate base | Actuals tables are separate from `saved_projections` | PARTIAL |
| ConsolidationGroup, FXRateSet | Absent | NOT_IMPLEMENTED |

There is no `tenant_id`. Scope is `companyId`. `organizations` are a firm layer. `gray_label_tenants` is hostname branding (`shared/schema.ts`).

## Accounting execution

`server/accounting/journalPosting.ts` posts invoice and bill recognition and payments with Decimal amounts and reference checks (`hasJournalReference`). Payments go through `runFinancialOperation` and `financial_operation_receipts`.

That is posting of a narrow document flow. It is not the V3 command pipeline for a general journal:

validate schema → authorize period → validate dimensions → balance → idempotency → approval → post atomically → emit `JournalPosted`.

There is no `JournalPosted` event. `audit_logs` records HTTP mutations with a correlation id and empty `beforeState` / `afterState` (`server/middleware/auditLogger.ts`).

Posted rows are not immutable. `PUT /transactions/:id` updates the row. `DELETE` and bulk delete hard-delete it (`server/storage` transaction methods). No `CREATE TRIGGER` in `migrations/*.sql`. No reversal document type. Grep of reversal language in `server/accounting` hits FX rate inversion in `exchangeRateSync.ts`, not accounting reversals.

## Period locks

`fiscal_period_status` supports open, closed, and locked. `isPeriodPostingBlocked` runs on create, update, and bulk import. It does not run on delete, bulk delete, recurring processing, or every invoice path. The update check looks at the new date, so a row can be moved out of a closed period. `fiscalPeriodFromDate` uses calendar month rather than `fiscal_year_configurations`. Year-end close loops `createTransaction` without a single database transaction and hardcodes `currency: "USD"`.

`requireApprovalAbove`, `approvalWorkflow`, and `dualAuthorization` on `companies` are written as defaults and not enforced.

## Calculation engine

`shared/projections/` is a large imperative engine: `growth_based/growthBasedCalculation.ts` (thousands of lines), `scenario/scenarioCalculations.ts`, `kpi/kpiCalculations.ts`, `ProjectionCoreEngine.ts`. The server runs it in `projectionCalculateService.ts` and calls `verifyThreeStatementIntegration`.

This is not the V3 language (`INPUT`, `LINK`, `FORMULA`, `FX`, `DEBT_SCHEDULE`, `VALUATION`, topological schedule, cycle failure). There is no cycle detector and no incremental descendant invalidation. `client/src/lib/calculationSourceRevision.ts` says revisions are local React Query hints, not server lineage.

Numeric type: projections use JavaScript numbers (`toFixed`, `Math.round`, `parseFloat`). The GL path uses decimal.js. `ENGINE_VERSION` in `shared/projections/engineVersion.ts` is the string `1.2.0`, not a build hash. Cache key is not `hash(model_version, input_hash, rate_set, engine_build)` as V3 specifies. Fingerprints of inputs and outputs are stored. The audit insert is logged and not required to succeed. `new Date()` fallbacks exist for projection start.

Tolerances: `CFO_VALIDATION_TOLERANCE = 1.0` in `ProjectionCoreEngine.ts`. Cash reconciliation allows `max(100, 0.5%)`.

## Reproducibility

Can the system answer “why is this number 42.7?” with source, mapping, adjustments, assumptions, formula, calculation version, engine version, scenario, FX policy, and approval?

| Ingredient | Present? |
| --- | --- |
| Source data | Partial. Upload jsonb or GL rows. Upload can be overwritten. |
| Mapping | `cfo_line_item_mappings` without version history. |
| Adjustments | Income-statement normalization rows, replaced as a set, default approved. |
| Assumptions | Inside projection `parameters` jsonb. |
| Formula | Static trace labels in `client/src/components/financial/trace/`. Not the executed expression. |
| Calculation version | Output fingerprint when the server path ran and the audit insert succeeded. |
| Engine version | Manual `1.2.0` on the server path. |
| Scenario | Name `conservative` / `base` / `aggressive`, not a pinned scenario id. |
| FX policy | Absent. Mismatch is rejected on upload. |
| Approval state | Board pack and review package only. Not on each metric. |

So the answer is no, not for a general reported number. A server projection run can show engine version, request id, and fingerprints (`attachLineage`). A board pack can freeze. A GL balance cannot be reconstructed from an immutable journal.

## Publication

V3: `DRAFT → VALIDATED → REVIEW → APPROVED → PUBLISHED`, with `REJECTED`.

Code: review packages move `draft → published` with a conditional update (`ingestionService.ts`). Board packs refuse edits after `publishedAt` (`boardPackLifecycle.ts`). Custom reports pin `publication_snapshot`. There is no validated, review, or approved stage and no maker-checker.

## Client truth

`PROJECTION_STRICT_SAVE` is true only when the environment variable is the string `"true"` (`projections.routes.ts`). Otherwise `/save` and `/auto-save` persist client `projectionData`, and the client can supply `outputFingerprint` and `validationPassed`. Server authority also depends on `companies.projection_server_authority`, an env default that is off outside production, and `?serverCalc=0`.

V7 exit criterion “failed calculation cannot publish” is therefore not met for the save path.

## Branch that moves toward a kernel

`audit/global-financial-engine-2026-07` (`4d526b4a7`) adds projection authority, fiscal periods, capex policy, DCF timing, covenant governance, and AI citation checks. It does not add journals, consolidation, or a DAG. It is 74 commits behind `dev` and cannot be merged cleanly.

`feat/guided-cfo-workspace` adds ledger posting/close policy and a journal draft list. It is a checkpoint and still tracks customer files.

## Verdict

| Test | Result on dev |
| --- | --- |
| Deterministic for the projection function given the same inputs | Mostly, with date fallbacks and float rounding |
| Deterministic as a system of record | No |
| Immutable history | No for GL and uploaded statements |
| Explain any material number | No |
| Safe for AI to sit beside | Mostly, if the categorize overwrite is closed |
