# 18 — Architecture Delta

## Current architecture (code)

```text
Browser (React/Vite)
  ├─ local projection engines when server authority is off
  ├─ Excel file export/import
  └─ session cookie
        │
        ▼
Express modular monolith
  ├─ localAuth, MFA, company RBAC
  ├─ accounting routes → transactions (mutable pairs)
  ├─ ingestion → uploaded statement JSON (replace in place)
  ├─ projectionCalculateService → shared/projections (floats)
  ├─ modelingEvaluate + LBO
  ├─ board pack PDF
  ├─ OpenRouter chat, read-only tools
  └─ NexaDeals handoff token
        │
        ├─ PostgreSQL (companies, not a financial-state aggregate)
        ├─ GCS / local uploads / Git-tracked data-room files
        ├─ Postgres job table
        └─ Sentry
```

There is no consolidation service, FX service, calculation graph, vector index, or Excel add-in.

## Intended architecture (V1–V13)

```text
Web + Excel add-in + APIs
        │
        ▼
Identity + tenant context
        │
        ▼
Domain APIs (/v1) with idempotency and expected version
        │
        ├─ Financial state (immutable published versions)
        ├─ Accounting journals
        ├─ Consolidation
        ├─ FX rate sets
        ├─ Calculation graph
        ├─ Model / scenario / valuation
        ├─ Reporting from a state id
        └─ AI gateway (tools, no direct DB writes)
        │
        ▼
Postgres + object storage + authorized search + queue + audit events
```

V5 explicitly allows this to start as one deployable, with those ownership lines preserved in code. The current monolith does not keep those lines. The client calculates, the save path trusts the client, and two lanes both act as truth.

## Delta

```text
Current
  │
  ├─ Missing: canonical state, journal aggregate, reversals,
  │           consolidation, FX translation, DAG, lineage API,
  │           Excel add-in, RAG, diligence ACL, 13-week engine,
  │           QoE, onboarding certificate, IaC
  │
  ├─ Conflicting: client-saved forecasts, mutable posted rows,
  │               mixed-currency sums, marketed features,
  │               AI account overwrite, book equity in EV blend
  │
  └─ Present and reusable: projection engines, DCF, LBO,
            board publication, session RBAC, debt schedules,
            cap table CRUD, bank-match locks, audit hash chain
        │
        ▼
Target V13 (only after the kernel delta is closed)
```

## Service map (actual)

| V5 component | Owns in spec | Owns in code |
| --- | --- | --- |
| Identity | Users, sessions | `localAuth.ts` |
| Financial state | Periods, facts, versions | Split across statement JSON and transactions |
| Accounting | Journals | `server/accounting` |
| Consolidation | Perimeter, NCI | Nobody |
| FX | Rate sets, translation | A live rate cache and a mismatch block |
| Calculation engine | Graph | `shared/projections` functions |
| Model service | Versions, assumptions | `saved_projections` |
| Valuation | Results, not the ledger | `modelingEvaluateService`, LBO |
| Reporting | Rendering, not truth | Board pack and statement React |
| AI gateway | Tools and policy | `aiClient.ts` + chat |
| Integration | Connectors, not truth | Upload and beta integrations |

## Financial-state lifecycle (actual)

```text
Upload file → parse → review package draft → publish (replace current)
or
Transaction insert → optional AI/learned account swap → row stored
        → optional update or delete
Forecast: inputs or client grid → saved_projections
Board: generate → publish (frozen PDF inputs)
```

## Financial-state lifecycle (specified)

```text
Import → map → reconcile → versioned facts → validate → review
→ approve → publish (immutable) → calculations pin that version
→ corrections are new versions or reversals
```

## Calculation dependency (actual)

The dependency graph is the call graph inside `growthBasedCalculation.ts` and its siblings, not data. Changing revenue growth recalculates the whole projection. There is no stored edge list and no cycle check.

## AI (actual)

See `10_AI_AUDIT.md`. Read-only tools over SQL, plus categorize side effect.

## M&A (actual)

```text
Capital Access originate → handoff token → NexaDeals
```

Specified origination-to-close loop is not in this repository.

## Onboarding (actual)

```text
Wizard → company row → optional file import → dashboard
```

## 13-week (actual)

Removed. Monthly projection cash and a runway number remain.

## Normalization / QoE (actual)

```text
Income-statement adjustment rows (default approved)
Board pack EBITDA waterfall (one period)
```

Specified flow through an approved adjustment set into QoE and a transaction bridge does not exist.

## Branch delta

`dev` ≈ `main` for product architecture. Extra architecture lives on `feat/guided-cfo-workspace` (ledger policy) and `audit/global-financial-engine-2026-07` (forecast authority). Neither is the V5 target.
