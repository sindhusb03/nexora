# 17 — Infrastructure, DevOps, and Observability Audit

V5 asks for edge and WAF, API gateway, separate workers, Postgres, queue, object storage, search, audit store, AI gateway, Terraform or Kubernetes, and observability. The repository is a single Node process family on EC2.

## Present

| Piece | Evidence | Versus V5 |
| --- | --- | --- |
| Docker | Multi-stage `Dockerfile` (Node 20, non-root, Chromium for PDF, healthcheck) | Implemented differently |
| Compose | `docker-compose.yml`, `docker-compose.prod.yml` with ClamAV | Single app + scanner |
| Process manager | `ecosystem.config.cjs`, `server/cluster.ts` | PM2, not Kubernetes |
| CI | `.github/workflows/ci.yml`, `release.yml`, `security.yml`, `test.yml`, `lint.yml`, `docs.yml` | Stronger than many early codebases; not the V6 full gate |
| Deploy | `deploy.yml` SSH to EC2, pinned host keys, `production` environment | Not GitOps |
| Database | Postgres, Drizzle migrations, CI Postgres 15 | Matches the reference store |
| Queue | `backgroundJobQueue.ts` leases in Postgres | Not a separate broker |
| Object storage | `server/objectStorage.ts` (GCS) and local `uploads/` | Split brain with Git |
| Backups | `s3BackupService.ts` pg_dump to S3 | Restore unproven |
| Logs and errors | `centralizedLogger.ts`, Sentry at 10% traces | No OpenTelemetry metrics |
| Health | `server/routes/health.ts` | Liveness, not financial SLO |

## Absent

Terraform, Kubernetes, Helm, WAF-as-code, Prometheus, a vector index, a dedicated calculation worker, staging and pilot environment definitions, and a tested regional failover.

`PROJECTION_COMPUTE_REGION` does not place compute. It is logged.

## Observability of financial mutations

| Field V5/V12 want on a financial write | On `dev` |
| --- | --- |
| Tenant | Company id, sometimes from the session |
| Actor | `userId` on audit log |
| Command | HTTP method and path |
| Correlation id | Yes, header or generated |
| Causation id | No |
| Financial state version | No |
| Input version | Projection fingerprint when that path is used |
| Calculation run | Audit row best-effort |
| Engine version | On projection and modeling audits |
| Approval | Only where board or review status is stored |

Alerts in `financialAlertService.ts` cover cash and runway. They are business alerts for those metrics. They are not “headroom below policy” or “journal failed to balance,” and they are not SLO burn alerts.

## Classification

| Item | Class |
| --- | --- |
| Docker, CI, SSH deploy, Postgres, Sentry | Implemented differently from V5, and real |
| GCS and S3 backup code | Partial |
| Terraform, Kubernetes, vector search, AI gateway service | Documented in the spec, absent in the repo |
| Tracked `uploads/` | Implemented in the worst sense: durable in Git |

V5’s modular monolith allowance means the missing microservices are not, by themselves, a defect. The missing isolation is the defect: calculation, AI, and PDF rendering share the API process, and published financial state is not an operated object.
