# 15 — API and Data Model Audit

## API

There is no `/v1` financial API. Routes live under `/api/...` via `server/routes/modules/index.ts`, `server/accounting/routes.ts`, and `server/routes/remaining-legacy.routes.ts`. Swagger UI is mounted at `/api/docs` from `server/lib/swagger.ts` with an empty `apis` list. CI can emit `docs/api/openapi.snapshot.json`. That snapshot is not a schema gate.

`api_gap_matrix.csv` compares the V4/V6/V13 endpoints to actual routes. Summary:

| Specified | Actual | Gap |
| --- | --- | --- |
| `POST /v1/journals` | `POST /api/accounting/transactions` | Different resource, mutable |
| `POST /v1/imports`, mappings, reconciliations | Upload, mapping, bank match routes | Behavior partial, contract different |
| `GET /v1/financial-states/{id}` | None | Missing |
| `POST /v1/models/{id}/calculate` | `/api/cfo/projections/calculate` | Exists, plus a client save that bypasses it |
| `POST /v1/scenarios`, `/valuations`, `/report-packs` | Projection modes, valuation routes, board packs | Exist under other paths |
| `GET /v1/lineage/{type}/{id}` | Client trace maps | No API |
| V13 onboarding, cash, QoE, diligence, bridges | None at those paths | Missing |
| Idempotency-Key | Invoice/bill payments and Dodo billing events | Not general |
| Expected-Version | Custom reports only (`X-Report-Version`) | Not general |
| Error catalog `FIN_*`, `FX_RATE_MISSING`, `CALC_CYCLE_DETECTED` | Scattered HTTP errors; `FINANCIAL_SOURCE_CURRENCY_CONFLICT` exists | Catalog missing |

GraphQL was not found. Webhooks exist for billing (durable dedupe) and integrations (in-memory dedupe). Background work is a Postgres job table, not a published domain-event bus.

Undocumented APIs that are real: SCIM `/scim/v2`, gray-label admin, NexaDeals handoff, Dodo billing, GDPR, backup routes. See `19_UNDOCUMENTED_CAPABILITIES.md`.

## Data model versus V3/V6/V13

| Specified entity | Actual | Problem |
| --- | --- | --- |
| `tenant` | `companies` plus `organizations` plus `gray_label_tenants` | Three meanings of tenant |
| `legal_entity` | None | Subsidiaries are a jsonb list |
| `accounting_period` | `fiscal_period_status`, `fiscal_year_configurations` | Calendar-month helper ignores the fiscal configuration in places |
| `journal_entry` / `journal_line` | `transactions` single pair | Cannot represent a multi-line balanced document |
| `financial_fact` | `parsedData` jsonb and summed transactions | Not versioned |
| `fx_rate_set` | `exchange_rates` rows plus a memory cache | No set version |
| `model_node` | TypeScript functions | No stored graph |
| `calculation_run` | `projection_calculate_audit` | Best-effort insert |
| `onboarding_case`, `cash_week`, `qoe_case`, `diligence_request`, `transaction_bridge` | None | V13 model absent |
| Audit columns | `audit_logs` separate from row versions | Not on each financial row |
| Soft delete | None | Hard delete and `ON DELETE CASCADE` |
| Immutability | Convention on some version tables | No DB enforcement |

`debt_instruments.companyId` nullable with `userId` required is the sharpest bad key. `transactions.company_id` is required, which is better.

`0012_immutable_financial_context.sql` adds report snapshot columns. The name overstates the migration. It does not make journals immutable.

Migrations on `dev` run `0000` through `0013_lbo_model_versions.sql`. Two unmerged branches each introduce a different `0014`.

JSON is used for statement bodies, projection parameters, and subsidiaries. V3 said JSON must not hide core financial dimensions. Statement amounts inside `parsedData` are exactly that pattern.

## ER mismatch in one paragraph

The spec’s spine is tenant → legal entity → period → journal → fact → versioned state → calculation run. The database’s spine is user → company → either uploaded jsonb or transaction rows → saved projection jsonb → optional valuation version. Organization and gray-label sit beside company and do not replace entity. That is a domain mismatch, not a naming nit.
