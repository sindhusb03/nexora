# 22 — Gap Backlog

Machine-readable source: `gap_backlog.csv`. Complexity is S (days), M (one or two weeks), L (several weeks), XL (a quarter or more) for a small team that already knows this repo. These are engineering judgments, not quotes.

## P0 — Blocking

### P0-01 Remove tracked customer files

- Requirement: customer documents are not in Git.
- Version: V10.
- Status: files tracked on `dev` and `main`.
- Location: `uploads/a5628d05-1875-46d0-b976-ea8da0fc7f73/data-room/`.
- Branch: `fix/production-readiness-20260927` untracks them.
- Gap: 14 bank, statement, and HR files.
- Risk: critical exposure.
- Dependencies: none.
- Complexity: S for the index; history rewrite needs a human decision.
- Action: untrack and ignore `uploads/`. Decide separately whether to purge history.

### P0-02 Server-authoritative projection save

- Requirement: failed or client-built calculations cannot become the stored forecast.
- Version: V4, V7.
- Status: IMPLEMENTED_WITH_GAPS.
- Location: `server/routes/modules/projections.routes.ts`.
- Branch: `dev`. July branch has stronger authority.
- Gap: `PROJECTION_STRICT_SAVE` defaults off.
- Risk: wrong forecasts stored as if calculated.
- Dependencies: none.
- Complexity: M.
- Action: default the flag on, reject client grids, add a regression test.

### P0-03 Immutable journals and reversals

- Requirement: posted entries are not updated or deleted.
- Version: V3.
- Status: IMPLEMENTED_WITH_GAPS.
- Location: `transactions` and accounting routes.
- Branch: guided workspace has a checkpoint policy, unmerged.
- Gap: PUT and DELETE.
- Risk: books can be rewritten without a trail.
- Dependencies: P0-04.
- Complexity: L.
- Action: reversals only; cover with tests that hit the HTTP routes.

### P0-04 Period lock on every writer

- Requirement: closed periods reject postings.
- Version: V3.
- Status: IMPLEMENTED_WITH_GAPS.
- Location: `server/accounting/routes.ts`.
- Gap: delete, recurring, year-end, some invoices.
- Risk: closed periods are not closed.
- Dependencies: none.
- Complexity: M.
- Action: one guard used by every mutation.

### P0-05 Mixed currency fails closed

- Requirement: no unlabeled conversion.
- Version: V3.
- Status: PARTIAL.
- Location: transaction sums; `financialStatementCurrency.ts`.
- Gap: GL adds mixed currencies; upload blocks them.
- Risk: silent misstatement.
- Dependencies: a company-scoped rate read.
- Complexity: M.
- Action: refuse mixed totals until a rate-set version exists.

### P0-06 Company-scoped debt

- Requirement: tenant isolation.
- Version: V7.
- Status: IMPLEMENTED_WITH_GAPS.
- Location: `getDebtInstruments(userId)`.
- Gap: user-wide debt enters every company forecast.
- Risk: cross-company leakage into calculations.
- Dependencies: none.
- Complexity: S.
- Action: filter by `companyId` and test it.

### P0-07 Confirm account changes before post

- Requirement: AI proposes.
- Version: V1, V9.
- Status: IMPLEMENTED_WITH_GAPS.
- Location: `POST /transactions`.
- Gap: confidence > 0.7 overwrites accounts.
- Risk: unapproved classification.
- Dependencies: none.
- Complexity: S.
- Action: store the suggestion; post the user’s accounts unless they accept.

### P0-08 Versioned financial state

- Requirement: republish does not destroy the prior statement.
- Version: V3, V4.
- Status: NOT_IMPLEMENTED.
- Location: `ingestionService.ts`.
- Gap: in-place `parsedData` replacement.
- Risk: history loss.
- Dependencies: P0-03 for the GL side.
- Complexity: L.
- Action: new snapshot row per publish. Projections pin the snapshot id.

## P1 — Required for a honest MVP / production gate

| ID | Item | Complexity | Depends on |
| --- | --- | --- | --- |
| P1-01 | Port July DCF, fiscal, capex, covenant, citation fixes | L | P0-02 |
| P1-02 | FX translation and CTA | L | P0-05, P0-08 |
| P1-03 | Consolidation, or remove the marketing claim | XL to build, S to stop the claim | Entity model |
| P1-04 | New 13-week engine | L | P0-08 |
| P1-05 | Normalization proposed/approved ledger | M | P0-08 |
| P1-06 | QoE case and EBITDA identity | L | P1-05 |
| P1-07 | Onboarding certificate | L | P0-08 |
| P1-08 | Pricing and blog copy match the code | S | none |
| P1-09 | Audit before/after; fail closed on audit write | M | P0-03 |
| P1-10 | Run skipped Postgres suites in CI | M | disposable database |
| P1-11 | Prove backup restore | M | none |
| P1-12 | Merge session revocation; decide SAML | M | migration renumber for SAML |

## P2 — Required for full V13

Diligence and data-room ACL (XL, do not revive the deleted module unchanged), Excel add-in (XL, after lineage), covenant engine (M, port July work), cap table versions and waterfall (L), fundraising persistence (M), RAG after ACL (L), calculation DAG only after the current engine is authoritative (XL).

## P3 — Enterprise / scale

Second accounting basis, data residency, Terraform or Kubernetes, financial SLOs, 10k-node benchmark of whatever engine is real.

## P4 — Explicitly later in V4

Autonomous agent. Institutional trading workflows. Do not build these to “complete” the score.

Full field rows are in `gap_backlog.csv`.
