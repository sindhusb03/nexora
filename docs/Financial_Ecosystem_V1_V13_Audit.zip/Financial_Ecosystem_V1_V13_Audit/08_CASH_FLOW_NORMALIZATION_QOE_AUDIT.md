# 08 — Cash Flow, Normalization, and QoE Audit

Baseline: `dev` at `426751887`. V13 is the controlling spec. Earlier history matters because two of these features were built and removed.

## Statutory cash flow versus 13-week cash

The product has an indirect cash-flow statement (`client/src/components/financial/CashFlowReport.tsx`) and monthly cash from the projection engines. That is the accounting cash-flow statement, which V13 says is not the 13-week model.

The 13-week engine specified in V13 section 4 is absent:

```text
Ending Cash[w] = Beginning Cash[w] + collections + other receipts
                 − payroll − AP − taxes − capex − debt service − other outflows
                 + financing inflows − financing outflows
Beginning Cash[w] = Ending Cash[w−1]
Liquidity Headroom[w] = Ending Cash[w] − Minimum Cash[w]
```

No `cash_forecast` or `cash_week` table. No weekly buckets, collection curves, AP calendar, payroll calendar, tax calendar, capex register, debt-service week, minimum cash by entity, base/downside/upside overlays, actualization, or immutable prior forecast.

History:

- `69b8f6b3d` (2025-10-08) showed a 13-week tab when transactions were recent.
- `2a2caeedb` (2025-10-11) replaced it with a cash-balance waterfall.

Status: DEPRECATED. What remains is a pricing bullet in `server/routes/remaining-legacy.routes.ts` and blog text in `blogArticleContent.ts`. `financialAlertService.ts` alerts on cash balance and runway (`cashRunway.ts` uses gross expenses, not net burn). That is not V13 headroom.

V13 golden tests `V13-CASH-001` through `003` have no counterpart.

## Normalization

V13 requires an additive adjustment that stays `PROPOSED` until an authorized user approves it, with evidence, materiality, and reversibility. Rejected rows stay in the audit trail.

Code: `income_statement_normalization_adjustments` and `server/routes/modules/income-statement-normalization.routes.ts`. Saving deletes and re-inserts the set. New adjustments default to approved. There is no evidence reference array, no policy version, and no rejected-state history.

Status: IMPLEMENTED_WITH_GAPS, and the gap is the control model, not the existence of a table. Income-statement presentation can show adjustments. It is not a normalization ledger.

The older M&A QoE feature was removed in `55a422f95` (2026-01-14). Do not treat chat prompts that mention QoE (`chatService.ts`) as an engine.

## QoE

V13 section 6 requires revenue quality, recurring versus non-recurring, concentration, cohorts, margin bridge, EBITDA bridge from reported to normalized, working-capital history and peg, net debt, cash conversion, and `qoe_finding`.

Found: a one-period revenue → COGS → OpEx → EBITDA waterfall inside `boardPackGenerationService.ts`. That is a management bridge for a pack, not the QoE identity:

```text
Reported EBITDA + approved adjustments = Normalized EBITDA
```

No `qoe_case`, no findings, no customer concentration schedule, no cohort engine, no NWC peg.

Status: NOT_IMPLEMENTED.

## Transaction analytics link

V13 requires:

```text
Accounting → Normalization → QoE → EBITDA → Working capital → Net debt
→ Valuation → Purchase price → Equity value
```

The only quantitative bridge on `dev` is DCF equity value = enterprise value − debt + cash in `modelingEvaluateService.ts`. It does not read an approved adjustment set, a peg, or a transaction net-debt version. Purchase price is not stored as a separate term (V10 section 6).

Status: PARTIAL at the valuation step only. The chain is not connected.

## Tests

No golden test asserts the V13 cash roll-forward, unapproved-adjustment exclusion, EBITDA bridge identity, or evidence ACL. Three-statement cash tests cover the projection cash flow, which is a different statement.
