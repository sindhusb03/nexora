# 13 — Debt, Equity, Cap Table, and LBO Audit

V11 is the spec. V4 had marked the full LBO suite as later. V7 still requires a debt identity and an LBO sources-equals-uses fixture. Those fixtures are partly met. The capital-structure platform is not.

## Debt

Tables: `debt_instruments`, `debt_schedule`, `covenant_tracking`, `covenant_results` (`shared/schema.ts`). Routes: `server/routes/debt.routes.ts`. Schedules support amortization and PIK fields. Revolver activity feeds projections. `tests/debtAnnuitySafety` covers annuity behavior. Short-term and current long-term debt treatment was fixed on `dev` (`096ffb73e`, `8c816d74f`).

Gaps:

- Instruments are keyed by `userId` with nullable `companyId`. Projection load uses the user id.
- Covenant compliance is posted by the client (`POST /covenant-results`). The engine does not compute DSCR from a governed state.
- Interest rate sets are not versioned market curves. Floating-rate policy is not the V11 reference-rate version.
- The July branch aligns projected covenants and leverage to production debt rows. That alignment is not on `dev`.

Identity `opening + draws − repayments + interest = closing` is the intent of the schedule code and is not proven here as a single golden fixture for every facility type. Status: IMPLEMENTED_WITH_GAPS.

## Equity and cap table

`server/routes/modules/capital-markets.routes.ts` provides CRUD for equity rounds, cap table entries, option pools, and an investor CRM. `server/services/financialIntelligence/equity.ts` has a dilution check. Records can be filtered by user and an optional company id.

Missing versus V11: authorized-versus-issued invariant, atomic transfer (source down and destination up in one transaction), conversion lineage, published immutable cap table, option pool distinct from grants as a tested invariant.

Status: PARTIAL.

## Fundraising

`/request-funding`, `/apply-financing`, `/request-quote`, and `/apply` in `capital-access.routes.ts` return a generated id and a submitted status without inserting a round. Term-sheet parsing (`termSheetParsingService.ts`) is a real AI extraction into a stored term sheet. Debt raise, equity raise, and exit can originate a NexaDeals process deal.

V11’s rule that scenarios stay off the published cap table until close is not implemented, because those apply endpoints do not persist a scenario either.

Status: PARTIAL, with stub endpoints that report success.

## LBO

`server/services/valuation/lbo/` computes sources and uses, a monthly debt schedule, returns, a purchase-price solver, and sensitivity. Versions live in `valuation_model_versions`. UI under `client/src/components/valuation/lbo/`. `tests/lboEngine.test.ts` expects `closing.sources` to equal `closing.uses`.

IRR is `MOIC^(1/years) − 1`, which is a single-exit approximation, not a dated cash-flow IRR. Exit multiples exist here, not in the corporate DCF. There is no liquidation-preference waterfall. `ExitStrategy.tsx` computes client-side net proceeds as gross minus debt minus fees.

Status: IMPLEMENTED_WITH_GAPS for the sponsor model, NOT_IMPLEMENTED for the waterfall.

## Verdict

Debt schedules, cap table records, and LBO math are real product code and some of the best-tested finance in the repo. They are not wired to a canonical financial state, and covenants are not calculated. V11 exit criteria are not met.
