# 12 — M&A, Diligence, and Data Room Audit

V10 requires this lifecycle inside the product:

```text
ORIGINATION → NDA → DATA ROOM → DILIGENCE → VALUATION → INDICATION
→ NEGOTIATION → APPROVAL → SIGNING → CLOSING → CLOSED
```

V13 adds diligence workstreams (financial, commercial, tax, legal, operational, technology, HR, insurance, ESG) and evidence ACLs that can be narrower than the tenant. V4 had deferred the full marketplace and the advanced data room, then V10/V13 brought them back as later scope. They are in scope for V13, not for the V4 MVP.

## Current code

| Object | Status | Evidence |
| --- | --- | --- |
| Deal | External. `platformLinkService.ts` and `nexadealsPlatformClient.ts` call NexaDeals. Tokens in `platformHandoffService.ts`. Rows in `platform_deal_links` and `platform_firm_links`. Entry via capital-access originate. | PARTIAL handoff |
| Deal stage machine | Absent in LedgerMind | NOT_IMPLEMENTED |
| Party and confidentiality scope | Not an in-app model | NOT_IMPLEMENTED |
| Data room folder, hash, version, ACL | Module removed | DEPRECATED |
| Diligence request and finding | No tables | NOT_IMPLEMENTED |
| Valuation case pinned to a deal | Valuation models exist without a deal stage | PARTIAL, unconnected |
| Closing checklist | Absent | NOT_IMPLEMENTED |
| `deal_physics_*` | Term modeling (`dealPhysicsService.ts`), not a pipeline. `dev` redirects `/cfo/deal-physics` to the dashboard. | Not V10 |

“M&A Hub” in `client/src/lib/navigation.ts` relabels the CFO dashboard when `servicePreference` is M&A. It is not a deal system.

## History

A virtual data room with folders and versioning existed in late 2025 (`940cc365b`, `14b411500`, `09b64da0b`). It was removed by `7d8ac9329` and `d6a8c5dbc` (2026-02/03). M&A intelligence, including QoE content, was removed by `55a422f95` (2026-01-14).

Fourteen files under `uploads/a5628d05-1875-46d0-b976-ea8da0fc7f73/data-room/` are still tracked on `dev` and `main`: bank statements, financial-statement CSVs, and HR CSVs. The data-room **product** is gone. The data-room **files** are in Git. That is a critical exposure and also evidence the feature once stored customer documents on the app server.

`fix/production-readiness-20260927` untracks those paths. It does not rebuild an ACL.

## V13 connection

QoE and normalization do not feed a deal. There is no diligence finding that references a normalization adjustment or a valuation version. A counterparty cannot be shown a scoped room because the room does not exist.

## Verdict

In-app M&A completeness is about 8% (handoff only). Do not restore the deleted data room as the V10 design. The next implementation needs object storage, hashes, deal-scoped ACL, and audit of download, which the old module’s removal and the committed files both show was not a durable control.
