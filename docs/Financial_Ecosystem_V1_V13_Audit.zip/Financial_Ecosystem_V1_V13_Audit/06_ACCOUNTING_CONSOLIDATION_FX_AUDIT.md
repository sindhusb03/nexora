# 06 — Accounting, Consolidation, and FX Audit

Baseline: `dev` at `426751887`. No branch in the repository implements consolidation or FX translation.

## Accounting

### Double entry

`transactions` (`shared/schema.ts`, table built from `pgTable` around the accounts/transactions definitions) stores one debit account, one credit account, and one amount. A single row balances by construction. A multi-line journal is several rows that share a `reference`. There is no journal header, no entry status, and no line-level dimensions.

Chart of accounts is `accounts`, unique on `(companyId, code)`, with a `balance` column. Posting does not maintain that balance. `accountingCfoReconciliationService.ts` still reads `acct.balance` through `parseFloat` for a GL cash comparison. Trial-balance totals that sum `transactions.amount` are the live calculation.

Composite foreign keys tie debit and credit accounts to the same company, which blocks cross-tenant account ids.

### Posting, locks, reversals

Implemented posting helpers: `postAccrualInvoiceRecognition`, `postCashInvoicePaymentRecognition`, `postAccrualBillRecognition`, `postCashBillPaymentRecognition` in `server/accounting/journalPosting.ts`.

Not implemented:

- Reversals. Corrections are edits or deletes.
- Immutability after post.
- Period checks on delete and on recurring processing (`/recurring-transactions/:id/process`).
- A balanced multi-line validator, because the schema cannot represent an unbalanced single row. A set of rows that share a reference is not validated as one entry.
- Database triggers.

`deleteInvoice` and `deleteBill` remove the document and leave GL rows (`DatabaseStorage` invoice/bill delete). Those rows become unexplained history, and because history is also deletable, they can disappear without a reversal trail.

Year-end close (`planYearEndClosing` plus the route that posts it) is not one atomic transaction and writes `currency: "USD"`.

Bank reconciliation matching is the strongest accounting control: `server/accounting/reconciliation.ts` locks bank and ledger rows. The close-package path uses `bankAccount.currentBalance` as if it were the statement balance.

### Two lanes

| Lane | Tables | Writes truth? |
| --- | --- | --- |
| GL | `accounts`, `transactions`, invoices, bills, banks | Yes, mutable |
| CFO upload | `uploaded_financial_statements`, `ingest_facts` (hash only), `cfo_line_item_mappings` | Yes, replaced in place |

`ingestionService.ts` states that republish is a current-statement replacement, not an immutable revision. The only bridge is a read-only comparison in `accountingCfoReconciliationService.ts`. V3 required one fact model. The product has two, and neither is versioned the way the spec requires.

## Consolidation

Required by V3 section 5 and V7 section 6: effective-dated ownership, perimeter, basis normalization, translation, aggregation, intercompany match, elimination, NCI, reconciliation, publish.

Found:

- `companies.subsidiaries` jsonb and `companies.consolidatedReporting` boolean (`shared/schema.ts`).
- Settings UI edits the subsidiary string list.
- Line-item labels such as intercompany receivable in `shared/organizeBalanceSheetItems.ts` and `financialDataUtils.ts`.
- `isMonthlyConsolidated` means “roll months into a year,” not group accounting.
- `recalculateFinancingSubtotalAndConsolidateCash` is projection cash math.

Not found on any branch: parent/subsidiary table, ownership percent, effective dates, consolidation group, elimination journal, NCI, CTA, reporting perimeter.

`server/scripts/seedPricingPlans.ts` and `client/src/pages/blogArticleContent.ts` describe multi-entity consolidation and intercompany eliminations. That copy is ahead of the code. Commit history has no NCI implementation.

Consolidation is not deterministic because it does not exist. There is no hardcoded elimination formula to audit. The risk is the claim, not a wrong formula.

## Multi-currency

Required: transaction, functional, and presentation currency; versioned rate sets; historical, average, and closing rates; remeasurement; translation; CTA; explicit rounding; FX gain/loss; missing rates fail closed.

Found:

- `currencies` and `exchange_rates` (decimal 18,8, company-scoped columns).
- `transactions.currency`, `exchangeRate`, `baseAmount`.
- `companies.primaryCurrency`.
- Live rate fetch cached in memory (`exchangeRateSync.ts`). Identity pair returns rate 1, which is correct.
- Upload guard in `server/services/financialStatementCurrency.ts`: source and reporting currency must match until FX conversion is supported. Same check in `ingestionService.ts`. Conflict code `FINANCIAL_SOURCE_CURRENCY_CONFLICT`.

Not found:

- A writer that fills `transactions.exchangeRate` and `baseAmount` on the server.
- Callers of `getExchangeRates` that filter by company. The storage method does not filter by `companyId`.
- Historical, average, or closing rate selection.
- Remeasurement or CTA.
- A silent `rate = 1` fallback for missing pairs. The dangerous pattern in this codebase is different: amounts in different currencies are summed as if they were one currency (`storage` transaction sums).

## Verdict

| Area | Status | Risk |
| --- | --- | --- |
| Single-pair double entry | IMPLEMENTED_DIFFERENTLY | Medium, until multi-line entries are required |
| Immutable posted history | NOT_IMPLEMENTED | Critical |
| Period lock | IMPLEMENTED_WITH_GAPS | Critical |
| Consolidation | NOT_IMPLEMENTED | High, because it is marketed |
| FX translation | NOT_IMPLEMENTED | High |
| Mixed-currency summation | CONFLICT | High |
