# 24 — Implementation Roadmap

Sequence follows dependencies in the specs: V6 contracts and a trustworthy kernel before V8 Excel, V9 retrieval, and V13 analytics. Dates are not estimated. Complexity is in `22_GAP_BACKLOG.md`.

## Now — stop the bleeding

No new product surface.

1. P0-01 untrack `uploads/` and stop serving Git as a data room.
2. P1-08 remove consolidation and 13-week claims from pricing and blog copy.
3. P0-02 turn on strict projection save and reject client grids.
4. P0-06 scope debt by company.
5. P0-07 stop silent account replacement.
6. P1-12 merge session revocation after review. Hold SAML until the dependency and migration number are decided.
7. P1-10 and P1-11: CI databases and one real restore.

Exit: a forecast row is something the server computed; customer files are not in the tree; the worst cross-company and AI overwrite paths are closed.

## Next — make history real

8. P0-04 period lock on every writer.
9. P0-03 reversals; remove update and delete of posted rows.
10. P0-08 published statement versions.
11. P1-09 audit payload and fail-closed audit for those writes.
12. P0-05 refuse mixed-currency totals.
13. P1-01 port July fiscal, capex, DCF, covenant, and citation patches onto current `shared/projections` with golden tests. Do not merge that branch.

Exit: a closed period cannot change; a republish keeps the prior snapshot; projection authority matches the July review.

## Then — V4 loop is honest

14. Pin calculation runs to a financial-state version.
15. Lineage API for one statement line through mapping and engine version (the minimum V8 drill).
16. Scenario records that cannot overwrite actuals and that record the base version.
17. Valuation reads that pinned run. Remove book equity from the EV blend or label it as a separate method.
18. Board pack stores the state id it rendered.

Exit: the V4 journey is one version chain. Excel add-in is still not started.

## After the loop — V13 and capital controls

19. P1-05 normalization ledger.
20. P1-07 onboarding certificate that gates forecast publish.
21. P1-04 13-week model as a new engine.
22. P1-06 QoE on approved adjustments.
23. Covenant tests computed from the pinned state (July logic).
24. Persist fundraising or delete the stub success responses.
25. Cap table version on publish.

Exit: V13 quantitative identities have tests. Diligence can wait until evidence storage is not the Git tree.

## Later — V10, V8 Excel, V9 retrieval, V12

26. New data-room and diligence ACL on object storage.
27. Excel add-in against the lineage API.
28. Retrieval only with the same ACL as downloads.
29. FX translation and, only with an entity model, consolidation.
30. Second accounting basis as a policy layer.
31. Residency and IaC when there is a second region to operate.

## Explicitly not in this sequence

Rewriting `shared/projections` into a formula DAG before step 13. Merging `audit/global-financial-engine-2026-07` as a unit. Restoring the 2025 data room or the October 2025 13-week tab as-is. Building an autonomous agent.

## Branch handling during the roadmap

| Branch | Use |
| --- | --- |
| `dev` | Integration line |
| `fix/session-revocation-all-shapes` | Merge early |
| `fix/production-readiness-20260927` | Source for the uploads untrack, not for a full merge if guided workspace is chosen |
| `feat/guided-cfo-workspace` | Cherry-pick ledger policy after file hygiene |
| `feat/saml-signature-verification` | Separate decision |
| `audit/global-financial-engine-2026-07` | Port, do not merge |
| Obsolete six | Leave closed |

One writer at a time, per `AGENTS.md`. Financial ports need a human reviewer who did not write them.
