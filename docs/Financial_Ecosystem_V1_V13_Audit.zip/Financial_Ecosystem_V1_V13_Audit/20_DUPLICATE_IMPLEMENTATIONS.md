# 20 — Duplicate Implementations

Criteria used: which copy is on `dev`, which is tested, which matches V3–V7, and which is actually called. No winner is chosen from age or file size alone.

## 1. Two financial truths

| | CFO upload | GL transactions |
| --- | --- | --- |
| Newer | Continuously extended | Continuously extended |
| More complete for statements | Yes for historical IS/BS/CF files | Yes for invoices, bills, banks |
| Tested | Ingestion and report tests | Books integrity and reconciliation tests |
| Aligned to V3 facts | No | No |
| Used | CFO dashboard and projections read uploads | Accounting module |

**Recommendation:** keep both as inputs. Add a published snapshot that names which input version it used. Do not merge the tables in place.

## 2. Two projection executors

Same functions in `shared/projections`. One caller is `projectionCalculateService.ts`. The other is the React pages. Strict save is off.

**Recommendation:** one writer, the server. The client may preview only if the server returns the grid. The July branch’s authority checks are the better control layer and must be ported, not used as a second engine.

## 3. July audit engines versus `dev` engines

The July branch rewrites `ProjectionCoreEngine`, DCF, and projection routes and adds policy modules. `dev` has later product code the July branch does not have (LBO checkpoint, NexaDeals, SDLC). A merge deletes current code.

**Recommendation:** port policy modules onto `dev` with golden tests. `dev` remains the integration base.

## 4. Ledger posting

`journalPosting.ts` on `dev` versus `ledger*.ts` on `feat/guided-cfo-workspace`.

**Recommendation:** review the branch policy against current routes. Take the stricter close rules if tests pass. Do not replace the accounting module wholesale while the branch tracks customer files.

## 5. Valuation blends

DCF equity bridge, weighted average that can include book equity, market multiples with hard-coded zeros, and LBO exit value.

**Recommendation:** DCF and LBO are the tested engines. The weighted method needs an explicit policy so book equity is not an EV method. Multiples need a documented source and should not return silent zeros without a reason code.

## 6. Auth stacks

Session auth on `dev` (live). SAML on `feat/saml-signature-verification` (unmerged). Passport is mentioned only in the session-revocation branch as a session shape to revoke, not as a second login stack on `dev`.

**Recommendation:** session auth stays. SAML is an additional login method after review, not a replacement.

## 7. Membership tables

`user_company_memberships`, `team_members`, `organization_members`, and `company.userId` ownership. Risk register P0-003 called this out and deferred consolidation.

**Recommendation:** one authorization function already exists (`authorizationService.ts`). Do not add another table. Schedule a schema consolidation separately from the kernel.

## 8. Cash stories

Indirect cash-flow statement, monthly projection cash, runway, removed 13-week tab, pricing text.

**Recommendation:** keep the statement and the projection cash. Build V13 weekly cash as a new model. Delete the pricing claim until then.

## 9. Cap table versus exit waterfall

CRUD cap table versus `ExitStrategy.tsx` proceeds math.

**Recommendation:** cap table routes are the record. Exit screen math should call a shared function or be labeled as illustrative. It is not a V11 waterfall.

## 10. AI paths

`cfoBrain` pipeline, `chatService`, `openrouter.ts` direct fetches, categorization LLM, term-sheet parser, board-pack narrative.

**Recommendation:** one client (`aiClient.ts`) is already the center. Direct `fetch` to OpenRouter in `openrouter.ts` should go through it so policy is not split. Do not add a second gateway.
