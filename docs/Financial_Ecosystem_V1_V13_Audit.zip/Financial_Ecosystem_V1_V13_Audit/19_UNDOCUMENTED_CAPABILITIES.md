# 19 — Undocumented Capabilities

These exist in code and are missing from the V1–V13 PDFs, or the PDFs only hint at them. They should be kept, specified, or explicitly retired. They should not be deleted because they are absent from the pack.

| Existing capability | Code location | Branch | Not in spec | Recommendation |
| --- | --- | --- | --- | --- |
| Gray-label / white-label tenancy | `gray_label_tenants`, gray-label routes | `dev` | V5 tenancy is financial tenant, not hostname brand | Specify as a brand layer separate from `companyId` |
| Organization / firm above companies | `organizations`, `organizationPolicy.ts` | `dev` | V1 platform admin is close but not this model | Keep; document the firm versus company boundary |
| SCIM provisioning | `scim.routes.ts`, `scimService.ts` | `dev` | Not in V12 text | Keep; it is the enterprise identity path SAML was meant to join |
| NexaDeals identity handoff | `platformHandoffService.ts`, `platform_deal_links` | `dev` | V10 assumes an in-app deal | Specify as an external system of record for deals until V10 exists here |
| Dodo billing and payment event ledger | `dodo` routes, `dodo_billing_events` | `dev` | Not in the financial kernel spec | Keep; out of kernel scope |
| GDPR export and erasure | `gdpr` routes, `gdprService` | `dev`; fuller session revoke on `fix/session-revocation-all-shapes` | V12 privacy is only a heading | Keep and merge the session fix |
| Bank reconciliation with row locks | `server/accounting/reconciliation.ts` | `dev` | V4 reconciliation is import totals, not bank match | Keep; it is stronger than the spec’s sketch |
| Learned transaction patterns | categorization services | `dev` | V9 allows proposals, not silent overwrite | Keep the pattern store; stop applying it without confirmation |
| Board portal magic link | `board-portal.routes.ts` | `dev` | V1 board member is a role | Specify token scope and expiry as the board access model |
| KPI-driven forecast mode | `shared/projections/kpi/` | `dev` | V4 says scenarios, not three forecast methods | Document as a forecast method |
| External comps database (`pc_ratios_live`, precedent transactions) | `valuation.routes.ts` | `dev` | V4 says multiples framework, not this source | Document the source, the zeros for P/B and transaction P/E, and licensing |
| Payroll, inventory, fixed assets, AR/AP operations modules | `server/routes/modules/payroll`, `inventory`, `fixed-assets-cfo`, `arap` | `dev` | Not in V4 MVP module list | Keep behind launch flags; do not pretend they are the kernel |
| Hash-chained audit log | `audit_logs` | `dev` | V6 asks for audit events; the chain design is local | Keep and fix null before/after |
| Launch-state feature flags | `shared/launchCapabilities.ts`, `requireLaunchState` | `dev` | Not in V5 | Keep as the release switch |
| Projection and modeling fingerprint audits | `projection_calculate_audit`, `modeling_evaluate_audit` | `dev` | Close to V7 calculation run, unnamed | Promote into the lineage design rather than replacing |
| Five-country ledger groundwork | migrations `0014_five_country_ledger` | `feat/guided-cfo-workspace` only | V12 phase 1 is one jurisdiction | Review before merge; do not treat as shipped |
| Deal physics term model | `dealPhysicsService.ts` | `dev`, UI redirected | Not V10 lifecycle | Decide keep or remove; today it is unused surface |
| Cash runway and financial alerts | `cashRunway.ts`, `financialAlertService.ts` | `dev` | Not the V13 13-week alert | Keep as a dashboard metric; do not label it 13-week |
| Custom report publication snapshots | `customReportPublication.ts` | `dev` | Near V8 publish | Keep as the pattern for immutable outputs |
| Agent SDLC tooling | `AGENTS.md`, verify scripts | `dev` (not product) | Not in the financial spec | Ignore for V13 coverage |

Removed capabilities that the spec now requires again (data room, 13-week tab, M&A intelligence) are gaps, not undocumented features. They are recorded in `03_BRANCH_ANALYSIS.md`.
